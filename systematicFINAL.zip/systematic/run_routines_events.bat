@echo off
c:\XAMMP\mysql\bin\mysql -u root < c:\XAMMP\htdocs\systematic\database\routines_events.sql
