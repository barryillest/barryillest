@echo off
c:\XAMMP\mysql\bin\mysql -u root < c:\XAMMP\htdocs\systematic\database\schema.sql
