<?php
/**
 * User profile page for Task Management System
 */
// First include session management
require_once 'includes/session.php';

// Require login - this must happen BEFORE any HTML output
requireLogin();

// Now include the header which will output HTML
require_once 'includes/header.php';

// Get user data
$user_data = $user->getUserById($_SESSION['user_id']);

// Process profile update form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $current_password = $_POST['current_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    
    // Validate input
    $errors = [];
    
    if (empty($username)) {
        $errors[] = 'Username is required.';
    } elseif (strlen($username) < 3 || strlen($username) > 50) {
        $errors[] = 'Username must be between 3 and 50 characters.';
    }
    
    if (empty($email)) {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    
    // Check if password is being changed
    if (!empty($current_password) || !empty($new_password) || !empty($confirm_password)) {
        // Verify current password
        $result = $user->login($_SESSION['username'], $current_password);
        
        if (!$result) {
            $errors[] = 'Current password is incorrect.';
        } elseif (empty($new_password)) {
            $errors[] = 'New password is required.';
        } elseif (strlen($new_password) < 6) {
            $errors[] = 'New password must be at least 6 characters long.';
        } elseif ($new_password !== $confirm_password) {
            $errors[] = 'New passwords do not match.';
        }
    }
    
    if (empty($errors)) {
        try {
            // Update user profile
            $conn = $db->getConnection();
            
            // Start transaction
            $conn->beginTransaction();
            
            // Update username and email
            $stmt = $conn->prepare("
                UPDATE users 
                SET username = ?, email = ? 
                WHERE user_id = ?
            ");
            $stmt->execute([$username, $email, $_SESSION['user_id']]);
            
            // Update password if provided
            if (!empty($new_password)) {
                $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
                $stmt = $conn->prepare("
                    UPDATE users 
                    SET password = ? 
                    WHERE user_id = ?
                ");
                $stmt->execute([$password_hash, $_SESSION['user_id']]);
            }
            
            // Commit transaction
            $conn->commit();
            
            // Update session variables
            $_SESSION['username'] = $username;
            $_SESSION['email'] = $email;
            
            setFlashMessage('success', 'Profile updated successfully!');
            header("Location: profile.php");
            exit();
        } catch (PDOException $e) {
            // Rollback transaction
            $conn->rollBack();
            
            // Check for duplicate entry
            if ($e->getCode() == 23000) {
                if (strpos($e->getMessage(), 'username')) {
                    setFlashMessage('danger', 'Username already exists. Please choose another one.');
                } elseif (strpos($e->getMessage(), 'email')) {
                    setFlashMessage('danger', 'Email already exists. Please use another email.');
                } else {
                    setFlashMessage('danger', 'Profile update failed. Please try again.');
                }
            } else {
                setFlashMessage('danger', 'Profile update failed. Please try again.');
            }
        }
    } else {
        // Set error messages
        setFlashMessage('danger', implode('<br>', $errors));
    }
    
    // Redirect to refresh the page and show flash message
    header("Location: profile.php");
    exit();
}
?>

<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1 class="display-5 fw-bold" style="letter-spacing: -0.5px; color: #ffffff; font-family: 'Poppins', sans-serif;" data-aos="fade-right">My Profile</h1>
        <a href="dashboard.php" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; padding: 10px 20px; font-family: 'Poppins', sans-serif;" data-aos="fade-left">
            <i class="fas fa-arrow-left me-2" style="color: #ffffff;"></i>Back to Dashboard
        </a>
    </div>
    
    <div class="row">
        <div class="col-md-7">
            <div class="card" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up">
                <div class="card-header d-flex align-items-center justify-content-between" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; padding: 20px;">
                    <h5 class="mb-0" style="color: #ffffff; font-size: 18px; font-family: 'Poppins', sans-serif;">Profile Information</h5>
                </div>
                <div class="card-body" style="background-color: #000000; color: #ffffff; padding: 30px;">
                    <form method="POST" action="profile.php" id="userForm">
                        <div class="mb-4">
                            <label for="username" class="form-label" style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 10px;">Username <span style="color: #ff4d4d;">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333; border-right: none; color: #8e8e8e;"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user_data['username'] ?? ''); ?>" required style="background-color: #000000; border: 1px solid #333333; color: #ffffff; font-family: 'Poppins', sans-serif; padding: 12px 15px; height: auto;">
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="email" class="form-label" style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 10px;">Email <span style="color: #ff4d4d;">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333; border-right: none; color: #8e8e8e;"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email'] ?? ''); ?>" required style="background-color: #000000; border: 1px solid #333333; color: #ffffff; font-family: 'Poppins', sans-serif; padding: 12px 15px; height: auto;">
                            </div>
                        </div>
                        
                        <hr style="border-color: #333333; margin: 30px 0;">
                        <h5 class="mb-4" style="color: #ffffff; font-family: 'Poppins', sans-serif; font-size: 18px;">Change Password</h5>
                        <p style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 20px;">Leave these fields empty if you don't want to change your password.</p>
                        
                        <div class="mb-4">
                            <label for="current_password" class="form-label" style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 10px;">Current Password</label>
                            <div class="input-group">
                                <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333; border-right: none; color: #8e8e8e;"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="current_password" name="current_password" style="background-color: #000000; border: 1px solid #333333; color: #ffffff; font-family: 'Poppins', sans-serif; padding: 12px 15px; height: auto;">
                            </div>
                        </div>
                        
                        <div class="mb-4">
                            <label for="new_password" class="form-label" style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 10px;">New Password</label>
                            <div class="input-group">
                                <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333; border-right: none; color: #8e8e8e;"><i class="fas fa-key"></i></span>
                                <input type="password" class="form-control" id="new_password" name="new_password" style="background-color: #000000; border: 1px solid #333333; color: #ffffff; font-family: 'Poppins', sans-serif; padding: 12px 15px; height: auto;">
                            </div>
                            <small style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 12px; margin-top: 8px; display: block;">Password must be at least 6 characters long.</small>
                        </div>
                        
                        <div class="mb-4">
                            <label for="confirm_password" class="form-label" style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 10px;">Confirm New Password</label>
                            <div class="input-group">
                                <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333; border-right: none; color: #8e8e8e;"><i class="fas fa-key"></i></span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" style="background-color: #000000; border: 1px solid #333333; color: #ffffff; font-family: 'Poppins', sans-serif; padding: 12px 15px; height: auto;">
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-5">
                            <button type="submit" name="update_profile" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; padding: 10px 20px; font-family: 'Poppins', sans-serif;">
                                <i class="fas fa-save me-2" style="color: #ffffff;"></i>Update Profile
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-1"></div>
        <div class="col-md-4">
            <div class="card mb-4" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up" data-aos-delay="100">
                <div class="card-header" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; padding: 20px;">
                    <h5 class="mb-0" style="color: #ffffff; font-size: 18px; font-family: 'Poppins', sans-serif;">Account Information</h5>
                </div>
                <div class="card-body" style="background-color: #000000; color: #ffffff; padding: 20px;">
                    <ul class="list-group list-group-flush" style="background-color: #000000;">
                        <li class="list-group-item d-flex justify-content-between align-items-center" style="background-color: #000000; color: #ffffff; padding: 15px 0; border: none;">
                            <span style="color: #ffffff; font-family: 'Poppins', sans-serif;"><i class="fas fa-user-tag me-2" style="color: #8e8e8e;"></i>Role</span>
                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 16px; border-radius: 24px; font-family: 'Poppins', sans-serif;"><?php echo htmlspecialchars($user_data['role_name']); ?></span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center" style="background-color: #000000; color: #ffffff; padding: 15px 0; border: none;">
                            <span style="color: #ffffff; font-family: 'Poppins', sans-serif;"><i class="fas fa-toggle-on me-2" style="color: #8e8e8e;"></i>Status</span>
                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid <?php echo $user_data['is_active'] ? '#333333' : '#ff4d4d'; ?>; padding: 8px 16px; border-radius: 24px; font-family: 'Poppins', sans-serif;">
                                <?php echo $user_data['is_active'] ? 'Active' : 'Inactive'; ?>
                            </span>
                        </li>
                        <li class="list-group-item d-flex justify-content-between align-items-center" style="background-color: #000000; color: #ffffff; padding: 15px 0; border: none;">
                            <span style="color: #ffffff; font-family: 'Poppins', sans-serif;"><i class="fas fa-calendar-alt me-2" style="color: #8e8e8e;"></i>Member Since</span>
                            <span style="color: #8e8e8e; font-family: 'Poppins', sans-serif;"><?php echo date('M d, Y', strtotime($user_data['created_at'] ?? 'now')); ?></span>
                        </li>
                    </ul>
                </div>
            </div>
            
            <?php if ($user->isAdmin()): ?>
                <div class="card" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up" data-aos-delay="200">
                    <div class="card-header" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; padding: 20px;">
                        <h5 class="mb-0" style="color: #ffffff; font-size: 18px; font-family: 'Poppins', sans-serif;">Admin Options</h5>
                    </div>
                    <div class="card-body" style="background-color: #000000; color: #ffffff; padding: 20px;">
                        <div class="d-grid gap-2">
                            <a href="users.php" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; padding: 10px 20px; font-family: 'Poppins', sans-serif;">
                                <i class="fas fa-users me-2" style="color: #ffffff;"></i>Manage Users
                            </a>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
