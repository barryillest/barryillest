@echo off
c:\XAMMP\mysql\bin\mysql -u root < c:\XAMMP\htdocs\systematic\database\sample_data.sql
