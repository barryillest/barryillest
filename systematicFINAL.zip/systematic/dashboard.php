<?php
/**
 * Dashboard page for Task Management System
 */
// First include session management
require_once 'includes/session.php';

// Require login - this must happen BEFORE any HTML output
requireLogin();

// Now include the header which will output HTML
require_once 'includes/header.php';

// Get task statistics
$stats = $task->getTaskStatistics($_SESSION['user_id']);

// Get recent tasks
try {
    // $db is already a PDO connection
    $stmt = $db->prepare("
        SELECT t.*, c.category_name
        FROM tasks t
        JOIN categories c ON t.category_id = c.category_id
        WHERE t.user_id = ? AND t.status != 'archived'
        ORDER BY t.created_at DESC
        LIMIT 5
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $recent_tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    error_log("Database error: " . $e->getMessage());
    $recent_tasks = [];
}

// Get audit logs
if ($user->isAdmin()) {
    try {
        $conn = $db->getConnection();
        $stmt = $conn->prepare("
            SELECT a.*, u.username
            FROM audit_logs a
            LEFT JOIN users u ON a.changed_by = u.user_id
            ORDER BY a.timestamp DESC
            LIMIT 10
        ");
        $stmt->execute();
        $audit_logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch(PDOException $e) {
        error_log("Database error: " . $e->getMessage());
        $audit_logs = [];
    }
}
?>

<div class="container py-5">
    <h1 class="display-5 fw-bold mb-5" style="letter-spacing: -0.5px; text-decoration: none;" data-aos="fade-right">Dashboard</h1>
    
    <!-- Statistics Cards -->
    <div class="row mb-4 stat-cards-row">
        <div class="col-md-3 mb-3 stat-card-col">
            <div class="stat-card" data-aos="zoom-in">
                <i class="fas fa-tasks"></i>
                <div class="stat-value"><?php echo $stats['total_tasks'] ?? 0; ?></div>
                <div class="stat-label">Total Tasks</div>
            </div>
        </div>
        <div class="col-md-3 mb-3 stat-card-col">
            <div class="stat-card" data-aos="zoom-in" data-aos-delay="100">
                <i class="fas fa-clock"></i>
                <div class="stat-value"><?php echo $stats['pending_tasks'] ?? 0; ?></div>
                <div class="stat-label">Pending Tasks</div>
            </div>
        </div>
        <div class="col-md-3 mb-3 stat-card-col">
            <div class="stat-card" data-aos="zoom-in" data-aos-delay="200">
                <i class="fas fa-spinner"></i>
                <div class="stat-value"><?php echo $stats['in_progress_tasks'] ?? 0; ?></div>
                <div class="stat-label">In Progress</div>
            </div>
        </div>
        <div class="col-md-3 mb-3 stat-card-col">
            <div class="stat-card" data-aos="zoom-in" data-aos-delay="300">
                <i class="fas fa-check-circle"></i>
                <div class="stat-value"><?php echo $stats['completed_tasks'] ?? 0; ?></div>
                <div class="stat-label">Completed</div>
            </div>
        </div>
    </div>
    
    <!-- Quick Actions -->
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card mb-4" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;">
                <div class="card-header d-flex align-items-center justify-content-between" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333;">
                    <h5 class="mb-0" style="color: #ffffff; font-size: 18px;">Quick Actions</h5>
                </div>
                <div class="card-body" style="background-color: #000000; color: #ffffff; padding: 30px;">
                    <div class="quick-actions-container">
                        <div class="d-flex justify-content-center gap-4 w-100">
                            <a href="tasks.php?action=add" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 200px; height: 60px; display: flex; align-items: center; justify-content: center; padding: 18px;">
                                <i class="fas fa-plus-circle" style="margin-right: 12px; color: #ffffff;"></i>New Task
                            </a>
                            <a href="tasks.php" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 200px; height: 60px; display: flex; align-items: center; justify-content: center; padding: 18px;">
                                <i class="fas fa-list" style="margin-right: 12px; color: #ffffff;"></i>View All
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Recent Tasks -->
    <div class="row mb-5">
        <div class="col-md-12">
            <div class="card" style="background-color: #101010; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up" data-aos-delay="100">
                <div class="card-header py-3" style="background-color: #000000; border-bottom: 1px solid #333333;">
                    <h5 class="mb-0" style="color: #ffffff; text-decoration: none; font-size: 18px;">Recent Tasks</h5>
                </div>
                <div class="card-body py-4" style="background-color: #000000; color: #ffffff;">
                    <?php if (empty($recent_tasks)): ?>
                        <p class="text-center py-4" style="color: #8e8e8e;">No tasks found. Create your first task!</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover" style="background-color: #000000; color: #ffffff; border-color: #333333;">
                                <thead>
                                    <tr>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">TITLE</th>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">PRIORITY</th>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">STATUS</th>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">DUE DATE</th>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">ACTIONS</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($recent_tasks as $t): ?>
                                        <tr class="priority-<?php echo htmlspecialchars($t['priority']); ?>">
                                            <td class="py-3" style="color: #ffffff; font-size: 16px;"><?php echo htmlspecialchars($t['title']); ?></td>
                                            <td class="py-3" style="font-size: 16px;">
                                                <span class="badge <?php 
                                                    echo $t['priority'] === 'high' ? 'bg-danger' : 
                                                        ($t['priority'] === 'medium' ? 'bg-warning text-dark' : 'bg-info'); 
                                                ?> px-3 py-2" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                                    <?php echo ucfirst($t['priority']); ?>
                                                </span>
                                            </td>
                                            <td class="py-3" style="font-size: 16px;">
                                                <span class="badge <?php 
                                                    echo $t['status'] === 'pending' ? 'bg-secondary' : 
                                                        ($t['status'] === 'in_progress' ? 'bg-warning text-dark' : 
                                                        ($t['status'] === 'completed' ? 'bg-success text-white' : 'bg-secondary')); 
                                                ?> px-3 py-2" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                                    <?php echo ucfirst(str_replace('_', ' ', $t['status'])); ?>
                                                </span>
                                            </td>
                                            <td class="py-3" style="font-size: 16px;">
                                                <?php 
                                                if (!empty($t['due_date'])) {
                                                    $due_date = new DateTime($t['due_date']);
                                                    $today = new DateTime();
                                                    $interval = $today->diff($due_date);
                                                    $is_overdue = $due_date < $today && $t['status'] !== 'completed';
                                                    
                                                    echo $due_date->format('M d, Y');
                                                    
                                                    if ($is_overdue) {
                                                        echo ' <span class="badge px-2" style="background-color: #000000 !important; color: #ffffff !important; border: 1px solid #333333;">Overdue</span>';
                                                    } elseif ($interval->days <= 2 && $t['status'] !== 'completed') {
                                                        echo ' <span class="badge px-3 py-2" style="background-color: #000000 !important; color: #ffffff !important; border: 1px solid #333333;">Soon</span>';
                                                    }
                                                } else {
                                                    echo '<span class="text-muted">Not set</span>';
                                                }
                                                ?>
                                            </td>
                                            <td class="py-3" style="font-size: 16px;">
                                                <div class="d-flex gap-3">
                                                    <a href="tasks.php?action=view&id=<?php echo $t['task_id']; ?>" class="btn px-3 py-2" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 60px; height: 40px; display: inline-flex; align-items: center; justify-content: center; border-radius: 24px;" data-bs-toggle="tooltip" title="View">
                                                        <i class="fas fa-eye" style="color: #8e8e8e;"></i>
                                                    </a>
                                                    <a href="tasks.php?action=edit&id=<?php echo $t['task_id']; ?>" class="btn px-3 py-2" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 60px; height: 40px; display: inline-flex; align-items: center; justify-content: center; border-radius: 24px;" data-bs-toggle="tooltip" title="Edit">
                                                        <i class="fas fa-edit" style="color: #8e8e8e;"></i>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($user->isAdmin() && !empty($audit_logs)): ?>
    <!-- Recent Audit Logs (Admin only) -->
    <div class="row">
        <div class="col-md-12">
            <div class="card" style="background-color: #101010; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up" data-aos-delay="200">
                <div class="card-header" style="background-color: #000000; border-bottom: 1px solid #333333; padding: 20px;">
                    <h5 class="mb-0" style="color: #ffffff; text-decoration: none; font-size: 18px;">Activity Log</h5>
                </div>
                <div class="card-body" style="background-color: #000000; color: #ffffff;">
                    <div class="table-responsive">
                        <table class="table table-sm" style="background-color: #000000; color: #ffffff; border-color: #333333;">
                            <thead>
                                <tr>
                                    <th style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">TIME</th>
                                    <th style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">USER</th>
                                    <th style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">ACTION</th>
                                    <th style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">TABLE</th>
                                    <th style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">RECORD ID</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($audit_logs as $log): ?>
                                    <tr>
                                        <td><?php echo date('M d, H:i', strtotime($log['timestamp'])); ?></td>
                                        <td><?php echo htmlspecialchars($log['username'] ?? 'System'); ?></td>
                                        <td>
                                            <span class="badge bg-<?php 
                                                echo $log['action'] === 'INSERT' ? 'success' : 
                                                    ($log['action'] === 'UPDATE' ? 'info' : 'danger'); 
                                            ?>">
                                                <?php echo $log['action']; ?>
                                            </span>
                                        </td>
                                        <td><?php echo ucfirst($log['table_name']); ?></td>
                                        <td><?php echo $log['record_id']; ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Dashboard search functionality - filter tasks without redirecting
    const searchInput = document.getElementById('dashboardSearchInput');
    if (searchInput) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const taskRows = document.querySelectorAll('.table tbody tr');
            
            taskRows.forEach(function(row) {
                const title = row.querySelector('td:first-child').textContent.toLowerCase();
                const priority = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                const status = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                const dueDate = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
                
                if (title.includes(searchTerm) || priority.includes(searchTerm) || 
                    status.includes(searchTerm) || dueDate.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
            
            // Show/hide the 'no tasks found' message
            const noTasksMessage = document.querySelector('.table-responsive + p.text-center');
            const visibleRows = document.querySelectorAll('.table tbody tr[style="display: none;"]').length;
            const allRows = document.querySelectorAll('.table tbody tr').length;
            
            if (allRows > 0 && visibleRows === allRows) {
                // All rows are hidden, show the message
                if (!noTasksMessage) {
                    const tableResponsive = document.querySelector('.table-responsive');
                    const newMessage = document.createElement('p');
                    newMessage.className = 'text-center py-4';
                    newMessage.style.color = '#8e8e8e';
                    newMessage.innerHTML = 'No matching tasks found.';
                    tableResponsive.parentNode.appendChild(newMessage);
                }
            } else {
                // Some rows are visible, hide the message
                if (noTasksMessage) {
                    noTasksMessage.style.display = 'none';
                }
            }
        });
    }
    
    // Dashboard filter functionality
    const filterSelect = document.getElementById('dashboardFilterSelect');
    if (filterSelect) {
        filterSelect.addEventListener('change', function() {
            const filterValue = this.value.toLowerCase();
            const taskRows = document.querySelectorAll('.table tbody tr');
            
            taskRows.forEach(function(row) {
                if (filterValue === '') {
                    row.style.display = '';
                } else {
                    const statusCell = row.querySelector('td:nth-child(3)');
                    const statusText = statusCell.textContent.trim().toLowerCase();
                    
                    if (statusText.includes(filterValue)) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            });
        });
    }
});
</script>
