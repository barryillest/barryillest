<?php
/**
 * Event class for event management
 * 
 * This class demonstrates:
 * - STORED PROCEDURES: Uses database stored procedures for CRUD operations
 * - TRIGGERS: Relies on database triggers for audit logging (automatically executed)
 * - SCHEDULED EVENTS: Works with scheduled events for event archiving (runs in background)
 */
class Event {
    private $db;
    private $conn;

    /**
     * Constructor
     * @param mixed $db Database connection or Database object
     */
    public function __construct($db) {
        if ($db instanceof PDO) {
            $this->conn = $db;
        } else {
            // If we received a Database object instead of a PDO connection
            $this->db = $db;
            $this->conn = $db->getConnection();
        }
        
        // Ensure we have a valid connection
        if (!$this->conn) {
            throw new Exception("Database connection could not be established");
        }
    }
    
    /**
     * Get the database connection
     * @return PDO Database connection
     */
    public function getConnection() {
        return $this->conn;
    }
    
    /**
     * Execute a stored procedure (internal method)
     * 
     * @param string $procedure Procedure name
     * @param array $params Parameters for the procedure
     * @return array|bool Result set or false on failure
     */
    private function callProcedure($procedure, $params = []) {
        try {
            // If we have a Database object, use its callProcedure method
            if (isset($this->db) && method_exists($this->db, 'callProcedure')) {
                return $this->db->callProcedure($procedure, $params);
            }
            
            // Otherwise, execute the procedure directly with our PDO connection
            $placeholders = implode(',', array_fill(0, count($params), '?'));
            $sql = "CALL $procedure($placeholders)";
            
            // Log the SQL query for debugging
            error_log("Executing SQL: $sql with params: " . print_r($params, true));
            
            $stmt = $this->conn->prepare($sql);
            
            // Handle null values properly
            foreach ($params as $i => $param) {
                $paramType = PDO::PARAM_STR;
                if (is_int($param)) {
                    $paramType = PDO::PARAM_INT;
                } elseif (is_null($param)) {
                    $paramType = PDO::PARAM_NULL;
                }
                $stmt->bindValue($i+1, $param, $paramType);
            }
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error in callProcedure($procedure): " . $e->getMessage());
            return false;
        }
    }

    /**
     * Create a new event
     * 
     * @param int $routine_id Routine ID (optional)
     * @param string $title Event title
     * @param string $description Event description
     * @param int $user_id User ID
     * @param int $category_id Category ID
     * @param string $event_date Event date (YYYY-MM-DD)
     * @param string $start_time Start time (HH:MM:SS)
     * @param string $end_time End time (HH:MM:SS)
     * @param string $location Event location
     * @param string $priority Event priority
     * @return bool|int Event ID on success, false on failure
     */
    public function create($routine_id, $title, $description, $user_id, $category_id, 
                          $event_date, $start_time = null, $end_time = null, $location = null, $priority = 'medium') {
        try {
            // Call the stored procedure
            $result = $this->callProcedure('create_event', [
                $routine_id,
                $title,
                $description,
                $user_id,
                $category_id,
                $event_date,
                $start_time,
                $end_time,
                $location,
                $priority
            ]);
            
            if ($result && isset($result[0]['event_id'])) {
                $event_id = $result[0]['event_id'];
                // Log the event creation
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'created', 'event', $event_id, "Created event: $title");
                }
                return $event_id;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in event creation: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Update an event
     * 
     * @param int $event_id Event ID
     * @param string $title Event title
     * @param string $description Event description
     * @param int $category_id Category ID
     * @param string $event_date Event date (YYYY-MM-DD)
     * @param string $start_time Start time (HH:MM:SS)
     * @param string $end_time End time (HH:MM:SS)
     * @param string $location Event location
     * @param string $status Event status
     * @param string $priority Event priority
     * @return bool True if update successful, false otherwise
     */
    public function update($event_id, $title, $description, $category_id, $event_date, 
                         $start_time, $end_time, $location, $status, $priority) {
        try {
            // Get the user ID for logging
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
            
            // Call the stored procedure
            $result = $this->callProcedure('update_event', [
                $event_id,
                $title,
                $description,
                $category_id,
                $event_date,
                $start_time,
                $end_time,
                $location,
                $status,
                $priority
            ]);
            
            if ($result !== false) {
                // Log the event update
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'updated', 'event', $event_id, "Updated event: $title");
                }
                return true;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in event update: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete an event
     * 
     * @param int $event_id Event ID
     * @return bool True if deletion successful, false otherwise
     */
    public function delete($event_id) {
        try {
            // Get the user ID for logging
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
            
            // Get event details before deletion for logging
            $event = $this->getById($event_id);
            $event_title = $event ? $event['title'] : 'Unknown event';
            
            // Call the stored procedure
            $result = $this->callProcedure('delete_event', [$event_id]);
            
            if ($result !== false) {
                // Log the event deletion
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'deleted', 'event', $event_id, "Deleted event: $event_title");
                }
                return true;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in event deletion: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get event by ID
     * 
     * @param int $event_id Event ID
     * @return array|bool Event data or false if not found
     */
    public function getById($event_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT e.*, c.category_name, r.title as routine_title
                FROM events e
                JOIN categories c ON e.category_id = c.category_id
                LEFT JOIN routines r ON e.routine_id = r.routine_id
                WHERE e.event_id = ?
            ");
            $stmt->execute([$event_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get all events with optional filtering
     * 
     * @param string $status Filter by status
     * @param string $category_id Filter by category ID
     * @param string $user_id Filter by user ID
     * @param string $date_from Filter by date from (YYYY-MM-DD)
     * @param string $date_to Filter by date to (YYYY-MM-DD)
     * @return array Array of events
     */
    public function getAll($status = '', $category_id = '', $user_id = '', $date_from = '', $date_to = '') {
        try {
            $conn = $this->conn;
            
            // Build the query with potential filters
            $sql = "SELECT e.*, c.category_name, r.title as routine_title, u.username 
                   FROM events e
                   JOIN categories c ON e.category_id = c.category_id
                   LEFT JOIN routines r ON e.routine_id = r.routine_id
                   JOIN users u ON e.user_id = u.user_id
                   WHERE e.status != 'archived'";
            
            $params = [];
            
            // Add filters if provided
            if (!empty($status)) {
                $sql .= " AND e.status = ?";
                $params[] = $status;
            }
            
            if (!empty($category_id)) {
                $sql .= " AND e.category_id = ?";
                $params[] = $category_id;
            }
            
            if (!empty($user_id)) {
                $sql .= " AND e.user_id = ?";
                $params[] = $user_id;
            }
            
            if (!empty($date_from)) {
                $sql .= " AND e.event_date >= ?";
                $params[] = $date_from;
            }
            
            if (!empty($date_to)) {
                $sql .= " AND e.event_date <= ?";
                $params[] = $date_to;
            }
            
            $sql .= " ORDER BY e.event_date ASC, e.start_time ASC, e.priority DESC";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Exception in getAll: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get events by user ID with optional filtering
     * 
     * @param int $user_id User ID
     * @param string $status Filter by status
     * @param string $category_id Filter by category ID
     * @param string $date_from Filter by date from (YYYY-MM-DD)
     * @param string $date_to Filter by date to (YYYY-MM-DD)
     * @return array Array of events
     */
    public function getByUser($user_id, $status = '', $category_id = '', $date_from = '', $date_to = '') {
        try {
            // Use the getAll method with user_id filter
            return $this->getAll($status, $category_id, $user_id, $date_from, $date_to);
        } catch (Exception $e) {
            error_log("Exception in getByUser: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get upcoming events for a user
     * 
     * @param int $user_id User ID
     * @param int $days Number of days to look ahead
     * @return array Array of upcoming events
     */
    public function getUpcoming($user_id, $days = 7) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT e.*, c.category_name, r.title as routine_title
                FROM events e
                JOIN categories c ON e.category_id = c.category_id
                LEFT JOIN routines r ON e.routine_id = r.routine_id
                WHERE e.user_id = ? 
                AND e.status != 'archived' AND e.status != 'cancelled'
                AND e.event_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL ? DAY)
                ORDER BY e.event_date ASC, e.start_time ASC, e.priority DESC
                LIMIT 20
            ");
            $stmt->execute([$user_id, $days]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get events for a specific date
     * 
     * @param int $user_id User ID
     * @param string $date Date (YYYY-MM-DD)
     * @return array Array of events on the specified date
     */
    public function getByDate($user_id, $date) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT e.*, c.category_name, r.title as routine_title
                FROM events e
                JOIN categories c ON e.category_id = c.category_id
                LEFT JOIN routines r ON e.routine_id = r.routine_id
                WHERE e.user_id = ? 
                AND e.status != 'archived'
                AND e.event_date = ?
                ORDER BY e.start_time ASC, e.priority DESC
            ");
            $stmt->execute([$user_id, $date]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get events for the current day
     * 
     * @param int $user_id User ID
     * @return array Array of events for today
     */
    public function getToday($user_id) {
        return $this->getByDate($user_id, date('Y-m-d'));
    }

    /**
     * Get events for the current week
     * 
     * @param int $user_id User ID
     * @return array Array of events for this week
     */
    public function getThisWeek($user_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT e.*, c.category_name, r.title as routine_title
                FROM events e
                JOIN categories c ON e.category_id = c.category_id
                LEFT JOIN routines r ON e.routine_id = r.routine_id
                WHERE e.user_id = ? 
                AND e.status != 'archived'
                AND YEARWEEK(e.event_date, 1) = YEARWEEK(CURDATE(), 1)
                ORDER BY e.event_date ASC, e.start_time ASC, e.priority DESC
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get events for the current month
     * 
     * @param int $user_id User ID
     * @return array Array of events for this month
     */
    public function getThisMonth($user_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT e.*, c.category_name, r.title as routine_title
                FROM events e
                JOIN categories c ON e.category_id = c.category_id
                LEFT JOIN routines r ON e.routine_id = r.routine_id
                WHERE e.user_id = ? 
                AND e.status != 'archived'
                AND YEAR(e.event_date) = YEAR(CURDATE())
                AND MONTH(e.event_date) = MONTH(CURDATE())
                ORDER BY e.event_date ASC, e.start_time ASC, e.priority DESC
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }
}
?>
