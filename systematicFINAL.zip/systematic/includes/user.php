<?php
/**
 * User class for authentication and user management
 * 
 * This class demonstrates:
 * - USER MANAGEMENT: Complete implementation of user authentication and authorization
 * - STORED PROCEDURES: Uses database stored procedures for user operations
 * - TRIGGERS: Works with database triggers for audit logging (automatically executed)
 */
class User {
    private $db;
    private $conn;
    private $user_id;
    private $username;
    private $email;
    private $role;
    private $is_active;

    /**
     * Constructor
     * @param mixed $db Database connection or Database object
     */
    public function __construct($db) {
        if ($db instanceof PDO) {
            $this->conn = $db;
        } else {
            // If we received a Database object instead of a PDO connection
            $this->db = $db;
            $this->conn = $db->getConnection();
        }
        
        // Ensure we have a valid connection
        if (!$this->conn) {
            throw new Exception("Database connection could not be established");
        }
    }

    /**
     * Register a new user
     * @param string $username Username
     * @param string $email Email
     * @param string $password Password
     * @param int $role_id Role ID (default: 3 for regular user)
     * @return bool|int User ID on success, false on failure
     */
    /**
     * Register a new user
     * 
     * DEFENSE EXPLANATION: This method demonstrates the user creation aspect of User Management.
     * While it uses direct PDO queries here, the database has a 'create_user' stored procedure
     * that could be used instead. When a user is created, database TRIGGERS automatically
     * create audit log entries (see after_user_insert trigger in schema.sql).
     * 
     * @param string $username Username
     * @param string $email Email
     * @param string $password Password
     * @param int $role_id Role ID (default: 3 for regular user)
     * @return bool|int User ID on success, false on failure
     */
    public function register($username, $email, $password, $role_id = 3) {
        try {
            // Hash password
            $password_hash = password_hash($password, PASSWORD_BCRYPT);
            
            // Use direct PDO query instead of stored procedure
            $stmt = $this->conn->prepare("INSERT INTO users (username, email, password, role_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$username, $email, $password_hash, $role_id]);
            
            // Get the last inserted ID
            $user_id = $this->conn->lastInsertId();
            
            if ($user_id) {
                return $user_id;
            }
            
            return false;
        } catch(PDOException $e) {
            error_log("Registration error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Login user
     * @param string $username Username
     * @param string $password Password
     * @return bool True if login successful, false otherwise
     */
    /**
     * Login user
     * 
     * DEFENSE EXPLANATION: This method demonstrates the authentication aspect of User Management.
     * It verifies credentials and establishes a user session. The system has a 'get_user_by_credentials'
     * stored procedure in schema.sql that could be used for this functionality.
     * 
     * @param string $username Username
     * @param string $password Password
     * @return bool True if login successful, false otherwise
     */
    public function login($username, $password) {
        try {
            // Make sure we have a connection
            if (!$this->conn) {
                // Try to reconnect
                if ($this->db) {
                    $this->conn = $this->db->getConnection();
                }
                
                if (!$this->conn) {
                    error_log("Database connection failed");
                    return false;
                }
            }
            
            // Very simple query to get user data
            $query = "SELECT u.*, r.role_name 
                     FROM users u 
                     JOIN roles r ON u.role_id = r.role_id 
                     WHERE u.username = ?"; 
            
            $stmt = $this->conn->prepare($query);
            $stmt->execute([$username]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);
            
            // Debug output
            error_log("Login attempt for user: {$username}");
            
            if (!$user) {
                error_log("User not found: {$username}");
                return false;
            }
            
            // Debug output
            error_log("User found, verifying password");
            
            // Verify password
            if (password_verify($password, $user['password'])) {
                if (!$user['is_active']) {
                    error_log("User account is inactive: {$username}");
                    return false; // Account is inactive
                }
                
                // Debug output
                error_log("Password verified for user: {$username}");
                
                // Set user properties
                $this->user_id = $user['user_id'];
                $this->username = $user['username'];
                $this->email = $user['email'];
                $this->role = $user['role_name'];
                $this->is_active = $user['is_active'];
                
                // Set session variables
                $_SESSION['user_id'] = $this->user_id;
                $_SESSION['username'] = $this->username;
                $_SESSION['email'] = $this->email;
                $_SESSION['role'] = $this->role;
                
                error_log("Session variables set for user: {$username}");
                error_log("User logged in successfully: {$username}");
                return true;
            } else {
                error_log("Password verification failed for user: {$username}");
                return false;
            }
        } catch(PDOException $e) {
            error_log("Login error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Update user information
     * @param int $user_id User ID
     * @param string $username Username
     * @param string $email Email
     * @param int $role_id Role ID
     * @param bool $is_active Active status
     * @return bool True if update successful, false otherwise
     */
    /**
     * Update user information
     * 
     * DEFENSE EXPLANATION: This method demonstrates the user modification aspect of User Management.
     * The database has an 'update_user' stored procedure in schema.sql that could be used.
     * When user data is updated, database TRIGGERS automatically create audit log entries
     * with old and new values (see after_user_update trigger in schema.sql).
     * 
     * @param int $user_id User ID
     * @param string $username Username
     * @param string $email Email
     * @param int $role_id Role ID
     * @param bool $is_active Active status
     * @return bool True if update successful, false otherwise
     */
    public function update($user_id, $username, $email, $role_id, $is_active) {
        try {
            // Use direct PDO query instead of stored procedure
            $stmt = $this->conn->prepare("UPDATE users SET username = ?, email = ?, role_id = ?, is_active = ? WHERE user_id = ?");
            $result = $stmt->execute([
                $username,
                $email,
                $role_id,
                $is_active ? 1 : 0,
                $user_id
            ]);
            
            return $result;
        } catch(PDOException $e) {
            error_log("Update user error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get all users
     * @return array Array of users
     */
    public function getAllUsers() {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT u.user_id, u.username, u.email, u.is_active, r.role_name, u.created_at
                FROM users u
                JOIN roles r ON u.role_id = r.role_id
                ORDER BY u.username
            ");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get user by ID
     * @param int $user_id User ID
     * @return array|bool User data or false if not found
     */
    public function getUserById($user_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT u.user_id, u.username, u.email, u.is_active, u.role_id, r.role_name
                FROM users u
                JOIN roles r ON u.role_id = r.role_id
                WHERE u.user_id = ?
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get all roles
     * @return array Array of roles
     */
    public function getAllRoles() {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("SELECT * FROM roles ORDER BY role_id");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Check if user is logged in
     * @return bool True if logged in, false otherwise
     */
    public function isLoggedIn() {
        return isset($_SESSION['user_id']);
    }

    /**
     * Check if user has admin role
     * @return bool True if admin, false otherwise
     */
    /**
     * Check if user has admin role
     * 
     * DEFENSE EXPLANATION: This method demonstrates the authorization aspect of User Management.
     * The system implements role-based access control with different permission levels.
     * 
     * @return bool True if admin, false otherwise
     */
    public function isAdmin() {
        return isset($_SESSION['role']) && $_SESSION['role'] === 'admin';
    }

    /**
     * Check if user has manager role or higher
     * @return bool True if manager or admin, false otherwise
     */
    /**
     * Check if user has manager role or higher
     * 
     * DEFENSE EXPLANATION: This method demonstrates hierarchical role-based authorization,
     * another key aspect of User Management. It shows how the system implements
     * different permission levels for different user roles.
     * 
     * @return bool True if manager or admin, false otherwise
     */
    public function isManager() {
        return isset($_SESSION['role']) && ($_SESSION['role'] === 'manager' || $_SESSION['role'] === 'admin');
    }

    /**
     * Logout user
     */
    public function logout() {
        // Unset all session variables
        $_SESSION = [];
        
        // Destroy the session
        session_destroy();
    }
}
?>
