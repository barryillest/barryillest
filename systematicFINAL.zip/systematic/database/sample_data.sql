USE task_management;

-- Insert a sample routine
INSERT INTO routines (title, description, user_id, category_id, frequency, start_date, end_date, days_of_week, status, priority)
VALUES ('Daily Exercise', 'Morning workout routine', 1, 4, 'daily', CURDATE(), DATE_ADD(CURDATE(), INTERVAL 30 DAY), NULL, 'active', 'high');

-- Get the routine_id
SET @routine_id = LAST_INSERT_ID();

-- Insert sample events
INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, start_time, end_time, location, status, priority)
VALUES 
(@routine_id, 'Morning Workout', '30 minutes cardio and strength training', 1, 4, CURDATE(), '07:00:00', '07:30:00', 'Home Gym', 'pending', 'high'),
(@routine_id, 'Morning Workout', '30 minutes cardio and strength training', 1, 4, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '07:00:00', '07:30:00', 'Home Gym', 'pending', 'high'),
(@routine_id, 'Morning Workout', '30 minutes cardio and strength training', 1, 4, DATE_ADD(CURDATE(), INTERVAL 2 DAY), '07:00:00', '07:30:00', 'Home Gym', 'pending', 'high');

-- Insert a standalone event (not associated with a routine)
INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, start_time, end_time, location, status, priority)
VALUES 
(NULL, 'Team Meeting', 'Weekly project status update', 1, 1, DATE_ADD(CURDATE(), INTERVAL 1 DAY), '10:00:00', '11:00:00', 'Conference Room A', 'pending', 'medium'),
(NULL, 'Doctor Appointment', 'Annual checkup', 1, 4, DATE_ADD(CURDATE(), INTERVAL 5 DAY), '14:30:00', '15:30:00', 'Medical Center', 'pending', 'high'),
(NULL, 'Birthday Party', 'John\'s birthday celebration', 1, 2, DATE_ADD(CURDATE(), INTERVAL 10 DAY), '18:00:00', '22:00:00', 'Restaurant Downtown', 'pending', 'medium');

-- Call the procedure to generate events from the routine
CALL generate_events_from_routine(@routine_id, DATE_ADD(CURDATE(), INTERVAL 3 DAY), DATE_ADD(CURDATE(), INTERVAL 10 DAY));
