USE task_management;

CREATE TABLE IF NOT EXISTS routines (
    routine_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    frequency ENUM('daily', 'weekly', 'monthly', 'custom') NOT NULL DEFAULT 'daily',
    start_date DATE NOT NULL,
    end_date DATE,
    days_of_week VARCHAR(20),
    status ENUM('active', 'paused', 'completed', 'archived') DEFAULT 'active',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

CREATE TABLE IF NOT EXISTS events (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    routine_id INT,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    event_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    location VARCHAR(255),
    status ENUM('pending', 'in_progress', 'completed', 'cancelled', 'archived') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id),
    FOREIGN KEY (routine_id) REFERENCES routines(routine_id) ON DELETE SET NULL
);

DROP PROCEDURE IF EXISTS create_routine;
DROP PROCEDURE IF EXISTS update_routine;
DROP PROCEDURE IF EXISTS get_routines_by_user;
DROP PROCEDURE IF EXISTS delete_routine;
DROP PROCEDURE IF EXISTS create_event;
DROP PROCEDURE IF EXISTS update_event;
DROP PROCEDURE IF EXISTS get_events_by_user;
DROP PROCEDURE IF EXISTS delete_event;
DROP PROCEDURE IF EXISTS generate_events_from_routine;

DELIMITER //
CREATE PROCEDURE create_routine(
    IN p_title VARCHAR(100),
    IN p_description TEXT,
    IN p_user_id INT,
    IN p_category_id INT,
    IN p_frequency ENUM('daily', 'weekly', 'monthly', 'custom'),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_days_of_week VARCHAR(20),
    IN p_priority ENUM('low', 'medium', 'high')
)
BEGIN
    INSERT INTO routines (title, description, user_id, category_id, frequency, start_date, end_date, days_of_week, priority)
    VALUES (p_title, p_description, p_user_id, p_category_id, p_frequency, p_start_date, p_end_date, p_days_of_week, p_priority);
    SELECT LAST_INSERT_ID() AS routine_id;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_routine(
    IN p_routine_id INT,
    IN p_title VARCHAR(100),
    IN p_description TEXT,
    IN p_category_id INT,
    IN p_frequency ENUM('daily', 'weekly', 'monthly', 'custom'),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_days_of_week VARCHAR(20),
    IN p_status ENUM('active', 'paused', 'completed', 'archived'),
    IN p_priority ENUM('low', 'medium', 'high')
)
BEGIN
    UPDATE routines
    SET title = p_title,
        description = p_description,
        category_id = p_category_id,
        frequency = p_frequency,
        start_date = p_start_date,
        end_date = p_end_date,
        days_of_week = p_days_of_week,
        status = p_status,
        priority = p_priority
    WHERE routine_id = p_routine_id;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_routines_by_user(
    IN p_user_id INT
)
BEGIN
    SELECT r.*, c.category_name
    FROM routines r
    JOIN categories c ON r.category_id = c.category_id
    WHERE r.user_id = p_user_id AND r.status != 'archived'
    ORDER BY r.start_date ASC, r.priority DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_routine(
    IN p_routine_id INT
)
BEGIN
    DELETE FROM routines WHERE routine_id = p_routine_id;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE create_event(
    IN p_routine_id INT,
    IN p_title VARCHAR(100),
    IN p_description TEXT,
    IN p_user_id INT,
    IN p_category_id INT,
    IN p_event_date DATE,
    IN p_start_time TIME,
    IN p_end_time TIME,
    IN p_location VARCHAR(255),
    IN p_priority ENUM('low', 'medium', 'high')
)
BEGIN
    INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, start_time, end_time, location, priority)
    VALUES (p_routine_id, p_title, p_description, p_user_id, p_category_id, p_event_date, p_start_time, p_end_time, p_location, p_priority);
    SELECT LAST_INSERT_ID() AS event_id;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE update_event(
    IN p_event_id INT,
    IN p_title VARCHAR(100),
    IN p_description TEXT,
    IN p_category_id INT,
    IN p_event_date DATE,
    IN p_start_time TIME,
    IN p_end_time TIME,
    IN p_location VARCHAR(255),
    IN p_status ENUM('pending', 'in_progress', 'completed', 'cancelled', 'archived'),
    IN p_priority ENUM('low', 'medium', 'high')
)
BEGIN
    UPDATE events
    SET title = p_title,
        description = p_description,
        category_id = p_category_id,
        event_date = p_event_date,
        start_time = p_start_time,
        end_time = p_end_time,
        location = p_location,
        status = p_status,
        priority = p_priority
    WHERE event_id = p_event_id;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE get_events_by_user(
    IN p_user_id INT
)
BEGIN
    SELECT e.*, c.category_name, r.title as routine_title
    FROM events e
    JOIN categories c ON e.category_id = c.category_id
    LEFT JOIN routines r ON e.routine_id = r.routine_id
    WHERE e.user_id = p_user_id AND e.status != 'archived'
    ORDER BY e.event_date ASC, e.start_time ASC, e.priority DESC;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE delete_event(
    IN p_event_id INT
)
BEGIN
    DELETE FROM events WHERE event_id = p_event_id;
END //
DELIMITER ;

DELIMITER //
CREATE PROCEDURE generate_events_from_routine(
    IN p_routine_id INT,
    IN p_start_date DATE,
    IN p_end_date DATE
)
BEGIN
    DECLARE v_title VARCHAR(100);
    DECLARE v_description TEXT;
    DECLARE v_user_id INT;
    DECLARE v_category_id INT;
    DECLARE v_frequency ENUM('daily', 'weekly', 'monthly', 'custom');
    DECLARE v_days_of_week VARCHAR(20);
    DECLARE v_priority ENUM('low', 'medium', 'high');
    DECLARE v_current_date DATE;
    DECLARE v_day_of_week INT;
    

    SELECT title, description, user_id, category_id, frequency, days_of_week, priority
    INTO v_title, v_description, v_user_id, v_category_id, v_frequency, v_days_of_week, v_priority
    FROM routines
    WHERE routine_id = p_routine_id;

    SET v_current_date = p_start_date;
    
    WHILE v_current_date <= p_end_date DO
     
        IF v_frequency = 'daily' THEN
            INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, priority)
            VALUES (p_routine_id, v_title, v_description, v_user_id, v_category_id, v_current_date, v_priority);

        ELSEIF v_frequency = 'weekly' THEN
            SET v_day_of_week = DAYOFWEEK(v_current_date);
            IF v_days_of_week IS NULL OR FIND_IN_SET(v_day_of_week, v_days_of_week) > 0 THEN
                INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, priority)
                VALUES (p_routine_id, v_title, v_description, v_user_id, v_category_id, v_current_date, v_priority);
            END IF;

        ELSEIF v_frequency = 'monthly' THEN
            IF DAY(v_current_date) = DAY(p_start_date) THEN
                INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, priority)
                VALUES (p_routine_id, v_title, v_description, v_user_id, v_category_id, v_current_date, v_priority);
            END IF;

        ELSEIF v_frequency = 'custom' AND v_days_of_week IS NOT NULL THEN
            SET v_day_of_week = DAYOFWEEK(v_current_date);
            IF FIND_IN_SET(v_day_of_week, v_days_of_week) > 0 THEN
                INSERT INTO events (routine_id, title, description, user_id, category_id, event_date, priority)
                VALUES (p_routine_id, v_title, v_description, v_user_id, v_category_id, v_current_date, v_priority);
            END IF;
        END IF;
        
        -- Move to next day... Aweeee
        SET v_current_date = DATE_ADD(v_current_date, INTERVAL 1 DAY);
    END WHILE;
END //
DELIMITER ;

DROP TRIGGER IF EXISTS after_routine_insert;
DROP TRIGGER IF EXISTS after_routine_update;
DROP TRIGGER IF EXISTS after_routine_delete;
DROP TRIGGER IF EXISTS after_event_insert;
DROP TRIGGER IF EXISTS after_event_update;
DROP TRIGGER IF EXISTS after_event_delete;

-- Trigger for routine audit logging hehe
DELIMITER //
CREATE TRIGGER after_routine_insert
AFTER INSERT ON routines
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, new_values)
    VALUES ('routines', NEW.routine_id, 'INSERT', NEW.user_id, 
            CONCAT('{"title":"', NEW.title, 
                  '","description":"', COALESCE(NEW.description, ''), 
                  '","category_id":', NEW.category_id, 
                  ',"frequency":"', NEW.frequency, 
                  '","start_date":"', NEW.start_date, 
                  '","end_date":"', COALESCE(NEW.end_date, ''), 
                  '","status":"', NEW.status, 
                  '","priority":"', NEW.priority, '"}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_routine_update
AFTER UPDATE ON routines
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, old_values, new_values)
    VALUES ('routines', NEW.routine_id, 'UPDATE', NEW.user_id,
            CONCAT('{"title":"', OLD.title, 
                  '","description":"', COALESCE(OLD.description, ''), 
                  '","category_id":', OLD.category_id, 
                  ',"frequency":"', OLD.frequency, 
                  '","start_date":"', OLD.start_date, 
                  '","end_date":"', COALESCE(OLD.end_date, ''), 
                  '","status":"', OLD.status, 
                  '","priority":"', OLD.priority, '"}'),
            CONCAT('{"title":"', NEW.title, 
                  '","description":"', COALESCE(NEW.description, ''), 
                  '","category_id":', NEW.category_id, 
                  ',"frequency":"', NEW.frequency, 
                  '","start_date":"', NEW.start_date, 
                  '","end_date":"', COALESCE(NEW.end_date, ''), 
                  '","status":"', NEW.status, 
                  '","priority":"', NEW.priority, '"}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_routine_delete
AFTER DELETE ON routines
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_values)
    VALUES ('routines', OLD.routine_id, 'DELETE',
            CONCAT('{"title":"', OLD.title, 
                  '","description":"', COALESCE(OLD.description, ''), 
                  '","category_id":', OLD.category_id, 
                  ',"frequency":"', OLD.frequency, 
                  '","start_date":"', OLD.start_date, 
                  '","end_date":"', COALESCE(OLD.end_date, ''), 
                  '","status":"', OLD.status, 
                  '","priority":"', OLD.priority, '"}'));
END //
DELIMITER ;

-- Trigger for event audit logging hehe
DELIMITER //
CREATE TRIGGER after_event_insert
AFTER INSERT ON events
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, new_values)
    VALUES ('events', NEW.event_id, 'INSERT', NEW.user_id, 
            CONCAT('{"title":"', NEW.title, 
                  '","description":"', COALESCE(NEW.description, ''), 
                  '","category_id":', NEW.category_id, 
                  ',"event_date":"', NEW.event_date, 
                  '","start_time":"', COALESCE(NEW.start_time, ''), 
                  '","end_time":"', COALESCE(NEW.end_time, ''), 
                  '","location":"', COALESCE(NEW.location, ''), 
                  '","status":"', NEW.status, 
                  '","priority":"', NEW.priority, '"}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_event_update
AFTER UPDATE ON events
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, old_values, new_values)
    VALUES ('events', NEW.event_id, 'UPDATE', NEW.user_id,
            CONCAT('{"title":"', OLD.title, 
                  '","description":"', COALESCE(OLD.description, ''), 
                  '","category_id":', OLD.category_id, 
                  ',"event_date":"', OLD.event_date, 
                  '","start_time":"', COALESCE(OLD.start_time, ''), 
                  '","end_time":"', COALESCE(OLD.end_time, ''), 
                  '","location":"', COALESCE(OLD.location, ''), 
                  '","status":"', OLD.status, 
                  '","priority":"', OLD.priority, '"}'),
            CONCAT('{"title":"', NEW.title, 
                  '","description":"', COALESCE(NEW.description, ''), 
                  '","category_id":', NEW.category_id, 
                  ',"event_date":"', NEW.event_date, 
                  '","start_time":"', COALESCE(NEW.start_time, ''), 
                  '","end_time":"', COALESCE(NEW.end_time, ''), 
                  '","location":"', COALESCE(NEW.location, ''), 
                  '","status":"', NEW.status, 
                  '","priority":"', NEW.priority, '"}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_event_delete
AFTER DELETE ON events
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_values)
    VALUES ('events', OLD.event_id, 'DELETE',
            CONCAT('{"title":"', OLD.title, 
                  '","description":"', COALESCE(OLD.description, ''), 
                  '","category_id":', OLD.category_id, 
                  ',"event_date":"', OLD.event_date, 
                  '","start_time":"', COALESCE(OLD.start_time, ''), 
                  '","end_time":"', COALESCE(OLD.end_time, ''), 
                  '","location":"', COALESCE(OLD.location, ''), 
                  '","status":"', OLD.status, 
                  '","priority":"', OLD.priority, '"}'));
END //
DELIMITER ;

-- Drop existing events if they exist. luh bo-ot2
DROP EVENT IF EXISTS generate_routine_events;
DROP EVENT IF EXISTS archive_old_events;

-- Scheduled event to generate upcoming events from routines (runs daily) ambot sa kabaw
DELIMITER //
CREATE EVENT generate_routine_events
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DECLARE v_routine_id INT;
    DECLARE v_end_date DATE;
    DECLARE v_done INT DEFAULT FALSE;
    DECLARE v_cursor CURSOR FOR 
        SELECT routine_id, IFNULL(end_date, DATE_ADD(CURDATE(), INTERVAL 30 DAY))
        FROM routines
        WHERE status = 'active';
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
    
    OPEN v_cursor;
    
    read_loop: LOOP
        FETCH v_cursor INTO v_routine_id, v_end_date;
        IF v_done THEN
            LEAVE read_loop;
        END IF;
        
        -- Generate events for the next 30 days if they don't exist already. sure oy?
        CALL generate_events_from_routine(
            v_routine_id, 
            CURDATE(), 
            LEAST(v_end_date, DATE_ADD(CURDATE(), INTERVAL 30 DAY))
        );
    END LOOP;
    
    CLOSE v_cursor;
END //
DELIMITER ;

-- Scheduled event to archive old events. yatia
DELIMITER //
CREATE EVENT archive_old_events
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    UPDATE events
    SET status = 'archived'
    WHERE status = 'completed'
    AND event_date < DATE_SUB(CURDATE(), INTERVAL 30 DAY);
END //
DELIMITER ;

-- Make sure event scheduler is turned on. Wee?
SET GLOBAL event_scheduler = ON;
