<?php
/**
 * Direct login script that bypasses the User class
 */
// Start session
session_start();

// Database connection
$host = "localhost";
$db_name = "task_management";
$username = "root";
$password = "";

try {
    // Connect to database
    $conn = new PDO("mysql:host=$host;dbname=$db_name", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // Create a test user if it doesn't exist
    $test_username = "testuser";
    $test_password = "password123";
    $hashed_password = password_hash($test_password, PASSWORD_DEFAULT);
    
    // Check if user exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$test_username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        // Create the user
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$test_username, 'test@example.com', $hashed_password, 3, 1]);
        echo "<p>Created test user: $test_username with password: $test_password</p>";
    } else {
        echo "<p>Test user already exists.</p>";
    }
    
    // Set session variables
    $_SESSION['user_id'] = $user ? $user['user_id'] : $conn->lastInsertId();
    $_SESSION['username'] = $test_username;
    $_SESSION['email'] = 'test@example.com';
    
    // Get role name
    $stmt = $conn->prepare("SELECT role_name FROM roles WHERE role_id = ?");
    $role_id = $user ? $user['role_id'] : 3;
    $stmt->execute([$role_id]);
    $role = $stmt->fetch(PDO::FETCH_ASSOC);
    $_SESSION['role'] = $role ? $role['role_name'] : 'user';
    
    echo "<p>You are now logged in as: $test_username</p>";
    echo "<p>Click <a href='dashboard.php'>here</a> to go to the dashboard.</p>";
    
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
