<?php
/**
 * Database configuration
 */
class Database {
    // Database credentials
    private $host = "localhost";
    private $db_name = "task_management";
    private $username = "root";
    private $password = "";
    private $conn;

    /**
     * Get the database connection
     * @return PDO|null
     */
    public function getConnection() {
        $this->conn = null;

        try {
            $this->conn = new PDO(
                "mysql:host=" . $this->host . ";dbname=" . $this->db_name,
                $this->username,
                $this->password
            );
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $this->conn->exec("set names utf8");
        } catch(PDOException $e) {
            echo "Connection error: " . $e->getMessage();
        }

        return $this->conn;
    }

    /**
     * Execute a stored procedure
     * @param string $procedure Procedure name
     * @param array $params Parameters for the procedure
     * @return array|bool Result set or false on failure
     */
    public function callProcedure($procedure, $params = []) {
        try {
            $conn = $this->getConnection();
            
            // Build parameter placeholders
            $placeholders = implode(',', array_fill(0, count($params), '?'));
            $sql = "CALL $procedure($placeholders)";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return false;
        }
    }
}
?>
