<?php
/**
 * Process registration form
 */

// Start session first - this must be at the very beginning
session_start();

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include necessary files
    require_once 'config/database.php';
    require_once 'includes/user.php';
    
    // Get form data
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    // Basic validation
    if (!empty($username) && !empty($email) && !empty($password) && $password === $confirm_password) {
        // Create database connection
        $database = new Database();
        $db = $database->getConnection();
        $user = new User($db);
        
        // Try to register the user
        try {
            $user_id = $user->register($username, $email, $password);
            
            if ($user_id) {
                // Success - store message in session
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Registration successful! Please login with your new account.'
                ];
                
                // Immediate redirect to login page
                header("Location: login.php");
                exit();
            } else {
                $error = 'Registration failed. Please try again.';
            }
        } catch (PDOException $e) {
            // Handle duplicate entry errors
            if ($e->getCode() == 23000) {
                if (strpos($e->getMessage(), 'username')) {
                    $error = 'Username already exists. Please choose another one.';
                } elseif (strpos($e->getMessage(), 'email')) {
                    $error = 'Email already exists. Please use another email or login.';
                } else {
                    $error = 'Registration failed. Please try again.';
                }
            } else {
                $error = 'Database error occurred. Please try again.';
            }
        }
    } else {
        // Validation errors
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'Please fill in all required fields.';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } else {
            $error = 'Please check your input and try again.';
        }
    }
    
    // If we get here, there was an error
    if (isset($error)) {
        $_SESSION['flash'] = [
            'type' => 'danger',
            'message' => $error
        ];
        
        // Redirect back to registration page
        header("Location: register.php");
        exit();
    }
} else {
    // Not a POST request, redirect to registration page
    header("Location: register.php");
    exit();
}
