/**
 * Main JavaScript file for Task Management System
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Task filter functionality
    const taskFilter = document.getElementById('taskFilter');
    if (taskFilter) {
        taskFilter.addEventListener('change', function() {
            const status = this.value;
            const taskItems = document.querySelectorAll('.task-item');
            
            taskItems.forEach(item => {
                if (status === 'all' || item.getAttribute('data-status') === status) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    // Task search functionality
    const taskSearch = document.getElementById('taskSearch');
    if (taskSearch) {
        taskSearch.addEventListener('input', function() {
            const searchTerm = this.value.toLowerCase();
            const taskItems = document.querySelectorAll('.task-item');
            
            taskItems.forEach(item => {
                const title = item.querySelector('.task-title').textContent.toLowerCase();
                const description = item.querySelector('.task-description') ? 
                                    item.querySelector('.task-description').textContent.toLowerCase() : '';
                
                if (title.includes(searchTerm) || description.includes(searchTerm)) {
                    item.style.display = 'block';
                } else {
                    item.style.display = 'none';
                }
            });
        });
    }

    // Confirm delete
    const deleteButtons = document.querySelectorAll('.delete-btn');
    deleteButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
                e.preventDefault();
            }
        });
    });

    // Due date validation
    const dueDateInputs = document.querySelectorAll('input[type="date"]');
    dueDateInputs.forEach(input => {
        input.addEventListener('change', function() {
            const selectedDate = new Date(this.value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (selectedDate < today) {
                alert('Warning: The selected date is in the past.');
            }
        });
    });

    // Task form validation
    const taskForm = document.getElementById('taskForm');
    if (taskForm) {
        taskForm.addEventListener('submit', function(e) {
            const titleInput = document.getElementById('title');
            const categoryInput = document.getElementById('category_id');
            
            if (titleInput.value.trim() === '') {
                e.preventDefault();
                alert('Task title is required');
                titleInput.focus();
                return false;
            }
            
            if (categoryInput.value === '') {
                e.preventDefault();
                alert('Please select a category');
                categoryInput.focus();
                return false;
            }
            
            return true;
        });
    }

    // User form validation
    const userForm = document.getElementById('userForm');
    if (userForm) {
        userForm.addEventListener('submit', function(e) {
            const usernameInput = document.getElementById('username');
            const emailInput = document.getElementById('email');
            const passwordInput = document.getElementById('password');
            const confirmPasswordInput = document.getElementById('confirm_password');
            
            if (usernameInput.value.trim() === '') {
                e.preventDefault();
                alert('Username is required');
                usernameInput.focus();
                return false;
            }
            
            if (emailInput.value.trim() === '') {
                e.preventDefault();
                alert('Email is required');
                emailInput.focus();
                return false;
            }
            
            // Only check password if it's a registration form or password is being changed
            if (passwordInput && confirmPasswordInput && 
                (passwordInput.value !== '' || confirmPasswordInput.value !== '')) {
                
                if (passwordInput.value.length < 6) {
                    e.preventDefault();
                    alert('Password must be at least 6 characters long');
                    passwordInput.focus();
                    return false;
                }
                
                if (passwordInput.value !== confirmPasswordInput.value) {
                    e.preventDefault();
                    alert('Passwords do not match');
                    confirmPasswordInput.focus();
                    return false;
                }
            }
            
            return true;
        });
    }

    // Add animation to task items
    const taskItems = document.querySelectorAll('.task-item');
    taskItems.forEach((item, index) => {
        item.setAttribute('data-aos', 'fade-up');
        item.setAttribute('data-aos-delay', (index * 50).toString());
    });

    // Add animation to dashboard stats
    const statCards = document.querySelectorAll('.stat-card');
    statCards.forEach((card, index) => {
        card.setAttribute('data-aos', 'zoom-in');
        card.setAttribute('data-aos-delay', (index * 100).toString());
    });

    // Task status change
    const statusSelects = document.querySelectorAll('.task-status-select');
    statusSelects.forEach(select => {
        select.addEventListener('change', function() {
            const taskId = this.getAttribute('data-task-id');
            const statusValue = this.value;
            const form = this.closest('form');
            
            if (form) {
                form.submit();
            }
        });
    });
});
