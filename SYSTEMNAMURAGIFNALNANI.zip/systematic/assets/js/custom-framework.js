/**
 * Custom Framework JS - Bootstrap Replacement
 * This file provides JavaScript functionality to replace Bootstrap components
 */

// Immediately invoked function expression to avoid polluting global namespace
(function() {
  'use strict';

  // Utility functions
  const util = {
    // Get an element by selector
    getElement: function(selector) {
      return document.querySelector(selector);
    },
    
    // Get all elements matching selector
    getElements: function(selector) {
      return document.querySelectorAll(selector);
    },
    
    // Add event listener
    addEvent: function(element, type, handler) {
      if (element) {
        element.addEventListener(type, handler);
      }
    },
    
    // Remove event listener
    removeEvent: function(element, type, handler) {
      if (element) {
        element.removeEventListener(type, handler);
      }
    },
    
    // Toggle class
    toggleClass: function(element, className) {
      if (element) {
        element.classList.toggle(className);
      }
    },
    
    // Add class
    addClass: function(element, className) {
      if (element && !element.classList.contains(className)) {
        element.classList.add(className);
      }
    },
    
    // Remove class
    removeClass: function(element, className) {
      if (element) {
        element.classList.remove(className);
      }
    },
    
    // Check if element has class
    hasClass: function(element, className) {
      if (element) {
        return element.classList.contains(className);
      }
      return false;
    }
  };

  // Dropdown component
  const dropdown = {
    init: function() {
      // Support both data-bs-toggle and data-toggle for backward compatibility
      const dropdownToggles = [...util.getElements('[data-bs-toggle="dropdown"]'), ...util.getElements('[data-toggle="dropdown"]')];
      
      dropdownToggles.forEach(toggle => {
        util.addEvent(toggle, 'click', function(e) {
          e.preventDefault();
          e.stopPropagation();
          
          // Find dropdown menu - either by target attribute or next sibling
          let target = document.querySelector(this.getAttribute('data-bs-target') || 
                                           this.getAttribute('data-target') ||
                                           this.getAttribute('href'));
          
          // If no target specified, look for sibling dropdown-menu
          if (!target) {
            const parent = this.closest('.dropdown');
            if (parent) {
              target = parent.querySelector('.dropdown-menu');
            }
          }
          
          if (!target) return;
          
          // Close all other dropdowns
          util.getElements('.dropdown-menu.show').forEach(menu => {
            if (menu !== target) {
              util.removeClass(menu, 'show');
            }
          });
          
          // Toggle current dropdown
          util.toggleClass(target, 'show');
          
          // Position dropdown correctly
          if (util.hasClass(target, 'dropdown-menu-end') || util.hasClass(target, 'dropdown-menu-right')) {
            target.style.left = 'auto';
            target.style.right = '0';
          } else {
            target.style.left = '0';
            target.style.right = 'auto';
          }
        });
      });
      
      // Close dropdowns when clicking outside
      util.addEvent(document, 'click', function(e) {
        if (!e.target.closest('.dropdown')) {
          util.getElements('.dropdown-menu.show').forEach(menu => {
            util.removeClass(menu, 'show');
          });
        }
      });
      
      // Add keyboard accessibility
      dropdownToggles.forEach(toggle => {
        util.addEvent(toggle, 'keydown', function(e) {
          if (e.key === 'Escape') {
            util.getElements('.dropdown-menu.show').forEach(menu => {
              util.removeClass(menu, 'show');
            });
            this.focus();
          }
        });
      });
    }
  };

  // Offcanvas component (sidebar)
  const offcanvas = {
    init: function() {
      // Support both data-bs-toggle and data-toggle for backward compatibility
      const offcanvasToggles = [...util.getElements('[data-bs-toggle="offcanvas"]'), ...util.getElements('[data-toggle="offcanvas"]')];
      const offcanvasDismiss = [...util.getElements('[data-bs-dismiss="offcanvas"]'), ...util.getElements('[data-dismiss="offcanvas"]')];
      
      offcanvasToggles.forEach(toggle => {
        util.addEvent(toggle, 'click', function(e) {
          e.preventDefault();
          
          // Support both data-bs-target and data-target for backward compatibility
          const targetSelector = this.getAttribute('data-bs-target') || this.getAttribute('data-target');
          const target = document.querySelector(targetSelector);
          if (!target) return;
          
          util.addClass(target, 'show');
          util.addClass(document.body, 'offcanvas-open');
          
          // Add backdrop
          const backdrop = document.createElement('div');
          backdrop.className = 'offcanvas-backdrop';
          document.body.appendChild(backdrop);
          
          setTimeout(() => {
            util.addClass(backdrop, 'show');
          }, 10);
          
          // Close when clicking backdrop
          util.addEvent(backdrop, 'click', function() {
            offcanvas.hide(target);
          });
        });
      });
      
      offcanvasDismiss.forEach(dismiss => {
        util.addEvent(dismiss, 'click', function(e) {
          e.preventDefault();
          const target = this.closest('.offcanvas');
          offcanvas.hide(target);
        });
      });
      
      // Ensure sidebar is visible on large screens
      const ensureSidebar = function() {
        const sidebar = document.querySelector('.sidebar.d-none.d-lg-block');
        const content = document.querySelector('.content');
        
        if (sidebar && window.innerWidth >= 992) {
          sidebar.style.display = 'block';
          if (content) {
            content.style.marginLeft = getComputedStyle(document.documentElement).getPropertyValue('--sidebar-width');
          }
        } else if (sidebar && window.innerWidth < 992) {
          sidebar.style.display = 'none';
          if (content) {
            content.style.marginLeft = '0';
          }
        }
      };
      
      // Run on init and window resize
      ensureSidebar();
      window.addEventListener('resize', ensureSidebar);
    },
    
    hide: function(offcanvasElement) {
      util.removeClass(offcanvasElement, 'show');
      util.removeClass(document.body, 'offcanvas-open');
      
      const backdrop = document.querySelector('.offcanvas-backdrop');
      if (backdrop) {
        util.removeClass(backdrop, 'show');
        setTimeout(() => {
          backdrop.remove();
        }, 300);
      }
    }
  };

  // Alert component
  const alert = {
    init: function() {
      // Support both data-bs-dismiss and data-dismiss for backward compatibility
      const alertCloseButtons = [...util.getElements('[data-bs-dismiss="alert"]'), ...util.getElements('[data-dismiss="alert"]')];
      
      alertCloseButtons.forEach(button => {
        util.addEvent(button, 'click', function() {
          const alert = this.closest('.alert');
          if (!alert) return;
          
          // If alert has 'fade' class, animate it out
          if (util.hasClass(alert, 'fade')) {
            util.removeClass(alert, 'show');
            setTimeout(() => {
              alert.remove();
            }, 300);
          } else {
            // Otherwise just remove it immediately
            alert.remove();
          }
        });
      });
      
      // Auto-close alerts with data-auto-dismiss attribute
      const autoCloseAlerts = util.getElements('.alert[data-auto-dismiss]');
      autoCloseAlerts.forEach(alert => {
        const delay = parseInt(alert.getAttribute('data-auto-dismiss')) || 5000;
        setTimeout(() => {
          if (util.hasClass(alert, 'fade')) {
            util.removeClass(alert, 'show');
            setTimeout(() => {
              alert.remove();
            }, 300);
          } else {
            alert.remove();
          }
        }, delay);
      });
    }
  };

  // Initialize all components
  document.addEventListener('DOMContentLoaded', function() {
    // Initialize dropdown functionality
    dropdown.init();
    
    // Add direct event listeners to all dropdown toggles for better compatibility
    document.querySelectorAll('[data-toggle="dropdown"]').forEach(function(element) {
      element.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        const parent = this.closest('.dropdown, .btn-group, .task-status-dropdown');
        if (!parent) return;
        
        const menu = parent.querySelector('.dropdown-menu');
        if (!menu) return;
        
        // Close all other dropdowns
        document.querySelectorAll('.dropdown-menu.show').forEach(function(openMenu) {
          if (openMenu !== menu) {
            openMenu.classList.remove('show');
          }
        });
        
        // Toggle current dropdown
        menu.classList.toggle('show');
        
        // Set aria-expanded attribute
        this.setAttribute('aria-expanded', menu.classList.contains('show') ? 'true' : 'false');
        
        // Position the dropdown menu below the toggle button for task status dropdowns
        if (parent.classList.contains('task-status-dropdown')) {
          const buttonRect = this.getBoundingClientRect();
          menu.style.top = buttonRect.bottom + 'px';
          menu.style.left = buttonRect.left + 'px';
        }
      });
    });
    
    // Close dropdowns when clicking outside
    document.addEventListener('click', function(e) {
      if (!e.target.closest('.dropdown, .btn-group, .task-status-dropdown')) {
        document.querySelectorAll('.dropdown-menu.show').forEach(function(menu) {
          menu.classList.remove('show');
        });
      }
    });
    
    // Special handling for task status dropdowns
    document.querySelectorAll('.task-status-dropdown .dropdown-toggle').forEach(function(button) {
      button.addEventListener('click', function(e) {
        const dropdownMenu = this.nextElementSibling;
        if (dropdownMenu && dropdownMenu.classList.contains('dropdown-menu')) {
          // Ensure the dropdown is visible and positioned correctly
          dropdownMenu.style.display = dropdownMenu.classList.contains('show') ? 'block' : 'none';
          dropdownMenu.style.position = 'absolute';
          dropdownMenu.style.zIndex = '1050';
          
          // Position below the button
          const rect = this.getBoundingClientRect();
          const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
          dropdownMenu.style.top = (rect.bottom + scrollTop) + 'px';
          dropdownMenu.style.left = rect.left + 'px';
        }
      });
    });
    
    offcanvas.init();
    alert.init();
    
    // Add CSS for offcanvas backdrop
    const style = document.createElement('style');
    style.textContent = `
      .offcanvas {
        position: fixed;
        top: 0;
        bottom: 0;
        left: 0;
        z-index: 1045;
        display: flex;
        flex-direction: column;
        max-width: 100%;
        visibility: hidden;
        background-color: #fff;
        background-clip: padding-box;
        outline: 0;
        transition: transform 0.3s ease-in-out;
        transform: translateX(-100%);
      }
      
      .offcanvas.show {
        transform: translateX(0);
        visibility: visible;
      }
      
      .offcanvas-backdrop {
        position: fixed;
        top: 0;
        left: 0;
        z-index: 1040;
        width: 100vw;
        height: 100vh;
        background-color: #000;
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
      }
      
      .offcanvas-backdrop.show {
        opacity: 0.5;
      }
      
      .offcanvas-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 1rem;
        border-bottom: 1px solid #dee2e6;
      }
      
      .offcanvas-body {
        flex-grow: 1;
        padding: 1rem;
        overflow-y: auto;
      }
      
      .fade-out {
        opacity: 0;
        transition: opacity 0.3s ease-in-out;
      }
    `;
    document.head.appendChild(style);
  });
})();
