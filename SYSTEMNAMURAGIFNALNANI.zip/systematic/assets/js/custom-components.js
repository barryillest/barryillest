/**
 * Custom JavaScript Components to Replace Bootstrap
 * This file provides vanilla JavaScript implementations of common Bootstrap components
 */

// Dropdown functionality
function initDropdowns() {
  const dropdownToggles = document.querySelectorAll('[data-toggle="dropdown"]');
  
  dropdownToggles.forEach(toggle => {
    const target = document.querySelector(toggle.getAttribute('data-target'));
    
    if (toggle && target) {
      toggle.addEventListener('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        
        // Close all other dropdowns
        document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
          if (menu !== target) {
            menu.classList.remove('show');
          }
        });
        
        // Toggle current dropdown
        target.classList.toggle('show');
      });
    }
  });
  
  // Close dropdowns when clicking outside
  document.addEventListener('click', function(e) {
    document.querySelectorAll('.dropdown-menu.show').forEach(menu => {
      if (!menu.contains(e.target)) {
        menu.classList.remove('show');
      }
    });
  });
}

// Alert dismissal
function initAlerts() {
  const closeButtons = document.querySelectorAll('.alert .btn-close');
  
  closeButtons.forEach(button => {
    button.addEventListener('click', function() {
      const alert = this.closest('.alert');
      alert.classList.remove('show');
      
      // After animation completes, remove from DOM
      setTimeout(() => {
        alert.remove();
      }, 150);
    });
  });
}

// Collapse functionality
function initCollapses() {
  const collapseToggles = document.querySelectorAll('[data-toggle="collapse"]');
  
  collapseToggles.forEach(toggle => {
    const targetId = toggle.getAttribute('data-target') || toggle.getAttribute('href');
    const target = document.querySelector(targetId);
    
    if (toggle && target) {
      toggle.addEventListener('click', function(e) {
        e.preventDefault();
        
        if (target.classList.contains('show')) {
          target.style.height = target.scrollHeight + 'px';
          
          // Force reflow
          target.offsetHeight;
          
          target.style.height = '0px';
          target.classList.remove('show');
          
          setTimeout(() => {
            target.style.height = '';
          }, 350);
        } else {
          target.style.height = '0px';
          target.classList.add('show');
          
          // Force reflow
          target.offsetHeight;
          
          target.style.height = target.scrollHeight + 'px';
          
          setTimeout(() => {
            target.style.height = '';
          }, 350);
        }
      });
    }
  });
}

// Sidebar toggle
function initSidebar() {
  const sidebarToggles = document.querySelectorAll('[data-toggle="offcanvas"]');
  
  sidebarToggles.forEach(toggle => {
    const targetId = toggle.getAttribute('data-target');
    const target = document.querySelector(targetId);
    
    if (toggle && target) {
      toggle.addEventListener('click', function(e) {
        e.preventDefault();
        target.classList.toggle('show');
      });
    }
  });
  
  // Close sidebar when clicking outside on mobile
  document.addEventListener('click', function(e) {
    const sidebar = document.querySelector('.sidebar.show');
    const toggle = document.querySelector('.sidebar-toggle');
    
    if (sidebar && toggle && !sidebar.contains(e.target) && !toggle.contains(e.target)) {
      sidebar.classList.remove('show');
    }
  });
}

// Tabs functionality
function initTabs() {
  const tabLinks = document.querySelectorAll('[data-toggle="tab"]');
  
  tabLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      const tabContent = document.querySelector(targetId);
      
      if (tabContent) {
        // Deactivate all tabs
        document.querySelectorAll('.tab-pane').forEach(pane => {
          pane.classList.remove('active', 'show');
        });
        
        document.querySelectorAll('[data-toggle="tab"]').forEach(tab => {
          tab.classList.remove('active');
        });
        
        // Activate clicked tab
        this.classList.add('active');
        tabContent.classList.add('active', 'show');
      }
    });
  });
}

// Modal functionality
function initModals() {
  const modalToggles = document.querySelectorAll('[data-toggle="modal"]');
  
  modalToggles.forEach(toggle => {
    const targetId = toggle.getAttribute('data-target');
    const target = document.querySelector(targetId);
    
    if (toggle && target) {
      toggle.addEventListener('click', function(e) {
        e.preventDefault();
        target.style.display = 'block';
        target.classList.add('show');
        document.body.classList.add('modal-open');
      });
      
      // Close modal when clicking close button
      const closeButtons = target.querySelectorAll('[data-dismiss="modal"]');
      closeButtons.forEach(button => {
        button.addEventListener('click', function() {
          target.classList.remove('show');
          setTimeout(() => {
            target.style.display = 'none';
            document.body.classList.remove('modal-open');
          }, 150);
        });
      });
      
      // Close modal when clicking outside
      target.addEventListener('click', function(e) {
        if (e.target === this) {
          target.classList.remove('show');
          setTimeout(() => {
            target.style.display = 'none';
            document.body.classList.remove('modal-open');
          }, 150);
        }
      });
    }
  });
}

// User avatar dropdown functionality (specific to this application)
function initUserDropdown() {
  const userAvatar = document.getElementById('userAvatar');
  const userDropdown = document.getElementById('userDropdown');
  const userMenuContainer = document.getElementById('userMenuContainer');
  
  if (userAvatar && userDropdown) {
    // Toggle dropdown when avatar is clicked
    userAvatar.addEventListener('click', function(e) {
      e.stopPropagation();
      userDropdown.style.display = userDropdown.style.display === 'none' ? 'block' : 'none';
    });
    
    // Close dropdown when clicking outside
    document.addEventListener('click', function(e) {
      if (userMenuContainer && !userMenuContainer.contains(e.target)) {
        userDropdown.style.display = 'none';
      }
    });
    
    // Prevent dropdown from closing when clicking inside it
    if (userDropdown) {
      userDropdown.addEventListener('click', function(e) {
        e.stopPropagation();
      });
    }
  }
}

// Initialize all components
document.addEventListener('DOMContentLoaded', function() {
  initDropdowns();
  initAlerts();
  initCollapses();
  initSidebar();
  initTabs();
  initModals();
  initUserDropdown();
});
