<?php
/**
 * Logout page for Task Management System
 */
require_once 'includes/session.php';

// Destroy the session
session_start();
$_SESSION = array();
session_destroy();

// Redirect to login page
header("Location: login.php");
exit();
?>
