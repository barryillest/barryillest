<?php
/**
 * Registration page for Task Management System
 */

// Start session first - this must be at the very beginning
session_start();

// Process form submission before any output
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Include necessary files
    require_once 'config/database.php';
    require_once 'includes/user.php';
    
    // Get form data
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $confirm_password = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    // Basic validation
    if (!empty($username) && !empty($email) && !empty($password) && $password === $confirm_password) {
        // Create database connection
        $database = new Database();
        $db = $database->getConnection();
        $user = new User($db);
        
        // Try to register the user
        try {
            $user_id = $user->register($username, $email, $password);
            
            if ($user_id) {
                // Success - store message in session
                $_SESSION['flash'] = [
                    'type' => 'success',
                    'message' => 'Registration successful! Please login with your new account.'
                ];
                
                // Immediate redirect to login page
                header("Location: login.php");
                exit();
            } else {
                $error = 'Registration failed. Please try again.';
            }
        } catch (PDOException $e) {
            // Handle duplicate entry errors
            if ($e->getCode() == 23000) {
                if (strpos($e->getMessage(), 'username')) {
                    $error = 'Username already exists. Please choose another one.';
                } elseif (strpos($e->getMessage(), 'email')) {
                    $error = 'Email already exists. Please use another email or login.';
                } else {
                    $error = 'Registration failed. Please try again.';
                }
            } else {
                $error = 'Database error occurred: ' . $e->getMessage();
            }
        }
    } else {
        // Validation errors
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'Please fill in all required fields.';
        } elseif ($password !== $confirm_password) {
            $error = 'Passwords do not match.';
        } else {
            $error = 'Please check your input and try again.';
        }
    }
    
    // If we get here, there was an error
    if (isset($error)) {
        $_SESSION['flash'] = [
            'type' => 'danger',
            'message' => $error
        ];
    }
}

// Include header for display
require_once 'includes/header.php';

// Get flash message if any
$flash = null;
if (isset($_SESSION['flash'])) {
    $flash = $_SESSION['flash'];
    unset($_SESSION['flash']);
}
?>
<link rel="stylesheet" href="assets/css/auth.css">

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-form">
                    <div class="card" style="background-color: #000000; border: 1px solid #333333;">
                        <div class="card-body">
                            <h2 class="card-title" style="color: #ffffff;">Create Account</h2>
                        
                        <form method="POST" action="process_register.php" id="userForm">
                            <div class="mb-3">
                                <label for="username" class="form-label" style="color: #ffffff;">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333;"><i class="fas fa-user" style="color: #ffffff;"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Choose a username" required autofocus style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                </div>
                                <small class="form-text" style="color: #cccccc;">Username must be between 3 and 50 characters.</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="email" class="form-label" style="color: #ffffff;">Email</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333;"><i class="fas fa-envelope" style="color: #ffffff;"></i></span>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="Enter your email address" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label" style="color: #ffffff;">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333;"><i class="fas fa-lock" style="color: #ffffff;"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Create a password" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                </div>
                                <small class="form-text" style="color: #cccccc;">Password must be at least 6 characters long.</small>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm_password" class="form-label" style="color: #ffffff;">Confirm Password</label>
                                <div class="input-group">
                                    <span class="input-group-text" style="background-color: #000000; border: 1px solid #333333;"><i class="fas fa-lock" style="color: #ffffff;"></i></span>
                                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" placeholder="Confirm your password" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                </div>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-outline-secondary" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; padding: 18px;">
                                    <i class="fas fa-user-plus" style="margin-right: 12px; color: #ffffff;"></i>Create Account
                                </button>
                            </div>
                        </form>
                        
                        <div class="mt-4 text-center">
                            <p style="color: #ffffff;">Already have an account? <a href="login.php" style="color: #ffffff; text-decoration: underline;">Sign in</a></p>
                            <p class="mt-3"><a href="index.php" class="btn btn-outline-secondary" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 60px; height: 60px; display: flex; align-items: center; justify-content: center; padding: 18px;"><i class="fas fa-home" style="margin-right: 12px; color: #ffffff;"></i>Back to Home</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
