<?php
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    // Return error response
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'User not logged in']);
    exit;
}

// Include database and task classes
require_once 'config/database.php';
require_once 'includes/task.php';
require_once 'includes/log.php';

// Check if the request is POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

// Get task_id and status from POST data
$task_id = isset($_POST['task_id']) ? intval($_POST['task_id']) : 0;
$status = isset($_POST['status']) ? $_POST['status'] : '';

// Validate inputs
if ($task_id <= 0) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid task ID']);
    exit;
}

// Validate status
if (!in_array($status, ['pending', 'in_progress', 'completed'])) {
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Invalid status value']);
    exit;
}

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Initialize task object
$task = new Task($db);

// Initialize log object
$log = new Log($db);

// Get the current task to check ownership and get original status
$task->task_id = $task_id;
$currentTask = $task->readOne();

// Check if task exists and belongs to the current user
if (!$currentTask || $currentTask['user_id'] != $_SESSION['user_id']) {
    // Users can only update their own tasks (unless they're admin)
    if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'message' => 'You do not have permission to update this task']);
        exit;
    }
}

// Attempt to update the task status
if ($task->updateStatus($task_id, $status)) {
    // Log the status change
    $originalStatus = $currentTask['status'];
    $log->user_id = $_SESSION['user_id'];
    $log->action = "Updated task status from '{$originalStatus}' to '{$status}'";
    $log->task_id = $task_id;
    $log->create();
    
    // Return success response
    header('Content-Type: application/json');
    echo json_encode(['success' => true, 'message' => 'Task status updated successfully']);
} else {
    // Return error response
    header('Content-Type: application/json');
    echo json_encode(['success' => false, 'message' => 'Failed to update task status']);
}
