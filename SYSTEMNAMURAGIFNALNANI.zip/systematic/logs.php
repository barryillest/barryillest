<?php
// Start output buffering to prevent "headers already sent" warnings
ob_start();

require_once 'includes/header.php';
require_once 'includes/log.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

// Initialize log object
$log = new Log($db);

// Handle delete log request
if (isset($_POST['delete_log']) && isset($_POST['log_id'])) {
    $log_id = $_POST['log_id'];
    if ($log->deleteLog($log_id, $_SESSION['user_id'])) {
        setFlashMessage('success', 'Log entry deleted successfully.');
    } else {
        setFlashMessage('danger', 'Failed to delete log entry.');
    }
    header('Location: logs.php');
    exit();
}

// Handle clear all logs request
if (isset($_POST['clear_all_logs'])) {
    if ($log->clearAllLogs($_SESSION['user_id'])) {
        setFlashMessage('success', 'All log entries cleared successfully.');
    } else {
        setFlashMessage('danger', 'Failed to clear log entries.');
    }
    header('Location: logs.php');
    exit();
}

// Get user logs
$logs = $log->getUserLogs($_SESSION['user_id']);

// Page title
$pageTitle = "My Activity Logs";
?>

<div class="container-fluid py-4">
    <div class="row">
        <div class="col-12">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-5 fw-bold mb-0" style="letter-spacing: -0.5px; text-decoration: none;" data-aos="fade-right"><?php echo $pageTitle; ?></h1>
                <?php if (!empty($logs)): ?>
                <form method="POST" action="logs.php" onsubmit="return confirm('Are you sure you want to clear all log entries? This action cannot be undone.');">
                    <button type="submit" name="clear_all_logs" class="btn btn-pill">
                        <i class="fas fa-trash-alt"></i> Clear History
                    </button>
                </form>
                <?php endif; ?>
            </div>
            
            <div class="card" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up">
                <div class="card-header" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; padding: 20px;">
                    <h5 class="card-title mb-0" style="color: #ffffff; font-size: 18px;">Recent Activities</h5>
                </div>
                <div class="card-body" style="background-color: #000000; color: #ffffff;">
                    <?php if (empty($logs)): ?>
                        <p class="text-muted">No activity logs found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover" style="background-color: #000000; color: #ffffff; border-color: #333333;">
                                <thead>
                                    <tr>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">ACTION</th>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">DETAILS</th>
                                        <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">DATE & TIME</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($logs as $log_entry): ?>
                                        <tr>
                                            <td style="color: #ffffff; font-size: 16px;">
                                                <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 12px; border-radius: 24px;">
                                                <?php 
                                                    // Use appropriate icon based on action
                                                    $action_icon = '';
                                                    if ($log_entry['action'] == 'created') {
                                                        $action_icon = '<i class="fas fa-plus-circle me-2" style="color: #8e8e8e;"></i>';
                                                    } elseif ($log_entry['action'] == 'updated') {
                                                        $action_icon = '<i class="fas fa-edit me-2" style="color: #8e8e8e;"></i>';
                                                    } elseif ($log_entry['action'] == 'deleted') {
                                                        $action_icon = '<i class="fas fa-trash-alt me-2" style="color: #8e8e8e;"></i>';
                                                    }
                                                    echo $action_icon . ucfirst($log_entry['action']) . ' ' . ucfirst($log_entry['entity_type']);
                                                ?>
                                                </span>
                                                <form method="POST" action="logs.php" class="d-inline ms-2" onsubmit="return confirm('Are you sure you want to delete this log entry?');">
                                                    <input type="hidden" name="log_id" value="<?php echo $log_entry['log_id']; ?>">
                                                    <button type="submit" name="delete_log" class="btn btn-sm" data-bs-toggle="tooltip" title="Delete Log" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; width: 30px; height: 30px; display: inline-flex; align-items: center; justify-content: center;">
                                                        <i class="fas fa-trash-alt" style="color: #8e8e8e;"></i>
                                                    </button>
                                                </form>
                                            </td>
                                            <td style="color: #ffffff; font-size: 16px;"><?php echo $log_entry['details']; ?></td>
                                            <td style="color: #ffffff; font-size: 16px;"><?php echo date('M j, Y g:i A', strtotime($log_entry['created_at'])); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
require_once 'includes/footer.php';
// End output buffering and flush
ob_end_flush();
?>
