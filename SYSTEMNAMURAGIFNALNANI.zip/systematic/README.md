# Task Management System

A simple task management system with CRUD functionality that implements:
- Stored Procedures
- Triggers
- Scheduled Events
- User Management

## Features
- User registration and authentication
- Create, read, update, and delete tasks
- Task categorization
- Task status tracking
- Audit logging via triggers
- Automated task cleanup via scheduled events
- Responsive minimalist UI with AOS animations

## Technologies
- PHP
- MySQL
- HTML5
- CSS3
- JavaScript
- AOS (Animate On Scroll)

## Installation
1. Clone this repository to your XAMPP htdocs folder
2. Import the database schema from `database/schema.sql`
3. Configure database connection in `config/database.php`
4. Access the application at `http://localhost/systematic/`

## Database Features
- **Stored Procedures**: Used for CRUD operations
- **Triggers**: Track changes to tasks and users
- **Scheduled Events**: Automatically archive completed tasks
- **User Management**: Registration, authentication, and role-based access
