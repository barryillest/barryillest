<?php
/**
 * Tasks management page for Task Management System
 */
// Start output buffering to prevent 'headers already sent' warnings
ob_start();

require_once 'includes/header.php';
require_once 'includes/log.php';
?>
<style>
/* Custom styles to override Bootstrap hover effects */
.status-option:hover {
    background-color: #333333 !important;
    color: #ffffff !important;
}
.dropdown-item:hover {
    background-color: #333333 !important;
    color: #ffffff !important;
}
.status-menu a:hover {
    background-color: #333333 !important;
    color: #ffffff !important;
}
/* Override any other Bootstrap hover effects */
.table-hover tbody tr:hover {
    background-color: #000000 !important;
    color: #ffffff !important;
}
.table-hover tbody tr:hover td {
    background-color: #000000 !important;
    color: #ffffff !important;
}
</style>

<?php
// Require login
requireLogin();

// Initialize variables
$action = $_GET['action'] ?? 'list';
$task_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create task
    if (isset($_POST['create_task'])) {
        $title = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $category_id = $_POST['category_id'] ?? '';
        $priority = $_POST['priority'] ?? 'medium';
        $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
        
        if (empty($title) || empty($category_id)) {
            setFlashMessage('danger', 'Please fill in all required fields.');
        } else {
            $result = $task->create($title, $description, $_SESSION['user_id'], $category_id, $priority, $due_date);
            
            if ($result) {
                // Directly create a log entry
                $log->create($_SESSION['user_id'], 'created', 'task', $result, "Created task: $title");
                
                setFlashMessage('success', 'Task created successfully!');
                header("Location: tasks.php");
                exit();
            } else {
                setFlashMessage('danger', 'Failed to create task. Please try again.');
            }
        }
    }
    
    // Update task
    if (isset($_POST['update_task'])) {
        $task_id = $_POST['task_id'] ?? '';
        $title = $_POST['title'] ?? '';
        $description = $_POST['description'] ?? '';
        $category_id = $_POST['category_id'] ?? '';
        $status = $_POST['status'] ?? 'pending';
        $priority = $_POST['priority'] ?? 'medium';
        $due_date = !empty($_POST['due_date']) ? $_POST['due_date'] : null;
        
        if (empty($title) || empty($category_id) || empty($task_id)) {
            setFlashMessage('danger', 'Please fill in all required fields.');
        } else {
            $result = $task->update($task_id, $title, $description, $category_id, $status, $priority, $due_date);
            
            if ($result) {
                // Directly create a log entry
                $log->create($_SESSION['user_id'], 'updated', 'task', $task_id, "Updated task: $title");
                
                setFlashMessage('success', 'Task updated successfully!');
                header("Location: tasks.php");
                exit();
            } else {
                setFlashMessage('danger', 'Failed to update task. Please try again.');
            }
        }
    }
    
    // Delete task
    if (isset($_POST['delete_task'])) {
        $task_id = $_POST['task_id'] ?? '';
        
        if (empty($task_id)) {
            setFlashMessage('danger', 'Invalid task ID.');
        } else {
            // Get task details before deletion for logging
            $taskDetails = $task->getTaskById($task_id);
            $taskTitle = $taskDetails ? $taskDetails['title'] : 'Unknown task';
            
            $result = $task->delete($task_id);
            
            if ($result) {
                // Directly create a log entry
                $log->create($_SESSION['user_id'], 'deleted', 'task', $task_id, "Deleted task: $taskTitle");
                
                setFlashMessage('success', 'Task deleted successfully!');
                header("Location: tasks.php");
                exit();
            } else {
                setFlashMessage('danger', 'Failed to delete task. Please try again.');
            }
        }
    }
    
    // AJAX endpoint for status updates
    if (isset($_POST['ajax_status_update'])) {
        $task_id = $_POST['task_id'] ?? '';
        $status = $_POST['status'] ?? '';
        
        // Debug information
        error_log("AJAX Status Update - Task ID: $task_id, Status: $status");
        
        if (empty($task_id) || empty($status)) {
            echo json_encode(['success' => false, 'message' => 'Invalid task ID or status.']);
            exit;
        }
        
        // Use the new direct status update method
        $update_result = $task->updateStatus($task_id, $status);
        
        if ($update_result) {
            // Create log entry
            $log->create($_SESSION['user_id'], 'updated', 'task', $task_id, 'Updated task status to: ' . ucfirst(str_replace('_', ' ', $status)));
            
            // Return success response
            echo json_encode([
                'success' => true, 
                'message' => 'Status updated successfully',
                'task_id' => $task_id,
                'status' => $status,
                'status_text' => ucfirst(str_replace('_', ' ', $status))
            ]);
            exit;
        } else {
            // Try a fallback method - direct query with no verification
            $conn = $task->getConnection();
            $stmt = $conn->prepare("UPDATE tasks SET status = ? WHERE task_id = ?");
            $fallback_result = $stmt->execute([$status, $task_id]);
            
            if ($fallback_result) {
                error_log("Used fallback method to update task ID: $task_id to status: $status");
                // Create log entry
                $log->create($_SESSION['user_id'], 'updated', 'task', $task_id, 'Updated task status to: ' . ucfirst(str_replace('_', ' ', $status)));
                
                // Return success response
                echo json_encode([
                    'success' => true, 
                    'message' => 'Status updated successfully (fallback method)',
                    'task_id' => $task_id,
                    'status' => $status,
                    'status_text' => ucfirst(str_replace('_', ' ', $status))
                ]);
                exit;
            } else {
                error_log("Both update methods failed for task ID: $task_id");
                echo json_encode(['success' => false, 'message' => 'Failed to update status in database.']);
                exit;
            }
        }
    }
    
    // Regular quick status update (non-AJAX fallback)
    if (isset($_POST['quick_status_update'])) {
        $task_id = $_POST['task_id'] ?? '';
        $status = $_POST['status'] ?? '';
        
        if (empty($task_id) || empty($status)) {
            setFlashMessage('danger', 'Invalid task ID or status.');
        } else {
            // Use the direct status update method for reliability
            $result = $task->updateStatus($task_id, $status);
            
            if ($result) {
                // Create log entry
                $log->create($_SESSION['user_id'], 'updated', 'task', $task_id, 'Updated task status to: ' . ucfirst(str_replace('_', ' ', $status)));
                setFlashMessage('success', 'Task status updated successfully!');
            } else {
                // Try fallback direct query
                $conn = $task->getConnection();
                $stmt = $conn->prepare("UPDATE tasks SET status = ? WHERE task_id = ?");
                $fallback_result = $stmt->execute([$status, $task_id]);
                
                if ($fallback_result) {
                    // Create log entry
                    $log->create($_SESSION['user_id'], 'updated', 'task', $task_id, 'Updated task status to: ' . ucfirst(str_replace('_', ' ', $status)));
                    setFlashMessage('success', 'Task status updated successfully (fallback method)!');
                } else {
                    setFlashMessage('danger', 'Failed to update task status. Please try again.');
                    error_log("Both update methods failed for task ID: $task_id in quick_status_update");
                }
            }
        }
        
        // Redirect back to the task list
        header("Location: tasks.php");
        exit();
    }
}

// Get categories for forms
$categories = $task->getAllCategories();

// Handle different actions
switch ($action) {
    case 'view':
        // Get task data
        $task_data = $task->getTaskById($task_id);
        
        if (!$task_data) {
            setFlashMessage('danger', 'Task not found.');
            header("Location: tasks.php");
            exit();
        }
        
        // Display task details
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-5 fw-bold" style="letter-spacing: -0.5px; color: #ffffff; font-family: 'Poppins', sans-serif;" data-aos="fade-right">Task Details</h1>
                <a href="tasks.php" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; padding: 10px 20px;" data-aos="fade-left">
                    <i class="fas fa-arrow-left me-2" style="color: #ffffff;"></i>Back to Tasks
                </a>
            </div>
            
            <div class="card" data-aos="fade-up" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 12px; box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);">
                <div class="card-header d-flex justify-content-between align-items-center" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; padding: 20px;">
                    <h5 class="mb-0" style="color: #ffffff; font-size: 20px; font-weight: 600; font-family: 'Poppins', sans-serif;"><?php echo htmlspecialchars($task_data['title']); ?></h5>
                    <div>
                        <?php if ($task_data['status'] === 'pending'): ?>
                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 16px; border-radius: 24px; font-family: 'Poppins', sans-serif;">Pending</span>
                        <?php elseif ($task_data['status'] === 'in_progress'): ?>
                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 16px; border-radius: 24px; font-family: 'Poppins', sans-serif;">In Progress</span>
                        <?php else: ?>
                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 16px; border-radius: 24px; font-family: 'Poppins', sans-serif;">Completed</span>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="card-body" style="background-color: #000000; color: #ffffff; padding: 30px;">
                    <div class="row mb-4">
                        <div class="col-md-5 mb-4">
                            <div class="p-4" style="background-color: #101010; border-radius: 12px; border: 2px solid #333333; height: 100%;">
                                <h6 style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-weight: 600; margin-bottom: 15px; text-transform: uppercase; font-size: 14px;">Description</h6>
                                <p style="color: #ffffff; font-family: 'Poppins', sans-serif; line-height: 1.6;"><?php echo !empty($task_data['description']) ? nl2br(htmlspecialchars($task_data['description'])) : '<span style="color: #8e8e8e;">No description provided</span>'; ?></p>
                            </div>
                        </div>
                        <div class="col-md-2"></div>
                        <div class="col-md-5">
                            <div class="p-4" style="background-color: #101010; border-radius: 12px; border: 2px solid #333333; height: 100%;">
                                <h6 style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-weight: 600; margin-bottom: 15px; text-transform: uppercase; font-size: 14px;">Task Details</h6>
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <p style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 5px;">Category</p>
                                        <p style="color: #ffffff; font-family: 'Poppins', sans-serif; font-weight: 500;"><?php echo htmlspecialchars($task_data['category_name']); ?></p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <p style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 5px;">Priority</p>
                                        <p style="color: #ffffff; font-family: 'Poppins', sans-serif; font-weight: 500;"><?php echo ucfirst($task_data['priority']); ?></p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <p style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 5px;">Due Date</p>
                                        <p style="color: #ffffff; font-family: 'Poppins', sans-serif; font-weight: 500;"><?php echo !empty($task_data['due_date']) ? date('M d, Y', strtotime($task_data['due_date'])) : '<span style="color: #8e8e8e;">Not set</span>'; ?></p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <p style="color: #8e8e8e; font-family: 'Poppins', sans-serif; font-size: 14px; margin-bottom: 5px;">Created</p>
                                        <p style="color: #ffffff; font-family: 'Poppins', sans-serif; font-weight: 500;"><?php echo date('M d, Y', strtotime($task_data['created_at'])); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex gap-3 justify-content-end mt-4">
                        <a href="tasks.php?action=edit&id=<?php echo $task_data['task_id']; ?>" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; padding: 10px 20px; font-family: 'Poppins', sans-serif;">
                            <i class="fas fa-edit me-2" style="color: #ffffff;"></i>Edit Task
                        </a>
                        <form method="POST" action="tasks.php" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this task?');">
                            <input type="hidden" name="task_id" value="<?php echo $task_data['task_id']; ?>">
                            <button type="submit" name="delete_task" class="btn btn-pill" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; padding: 10px 20px; font-family: 'Poppins', sans-serif;">
                                <i class="fas fa-trash-alt me-2" style="color: #ffffff;"></i>Delete Task
                            </button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php
        break;
    case 'add':
        // Display add task form
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-5 fw-bold" style="letter-spacing: -0.5px; text-decoration: none;" data-aos="fade-right">Create New Task</h1>
                <a href="tasks.php" class="btn btn-pill" data-aos="fade-left">
                    <i class="fas fa-arrow-left"></i> Back to Tasks
                </a>
            </div>
            
            <div class="card" data-aos="fade-up" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;">
                <div class="card-body" style="background-color: #000000; color: #ffffff;">
                    <form method="POST" action="tasks.php" id="taskForm">
                        <div class="mb-3">
                            <label for="title" class="form-label" style="color: #ffffff;">Task Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label" style="color: #ffffff;">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;"></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label for="category_id" class="form-label" style="color: #ffffff;">Category <span class="text-danger">*</span></label>
                                <select class="form-select" id="category_id" name="category_id" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                    <option value="">Select Category</option>
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['category_id']; ?>">
                                            <?php echo htmlspecialchars($category['category_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="priority" class="form-label" style="color: #ffffff;">Priority</label>
                                <select class="form-select" id="priority" name="priority" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                    <option value="low">Low</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="high">High</option>
                                </select>
                            </div>
                            
                            <div class="col-md-4 mb-3">
                                <label for="due_date" class="form-label" style="color: #ffffff;">Due Date</label>
                                <input type="date" class="form-control" id="due_date" name="due_date" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;" onfocus="this.showPicker()">
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="submit" name="create_task" class="btn btn-pill">
                                <i class="fas fa-save me-2"></i>Create Task
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
        break;
        
    case 'edit':
        // Get task data
        $task_data = $task->getTaskById($task_id);
        
        if (!$task_data) {
            setFlashMessage('danger', 'Task not found.');
            header("Location: tasks.php");
            exit();
        }
        
        // Check if user owns this task
        if ($task_data['user_id'] != $_SESSION['user_id'] && !$user->isAdmin()) {
            setFlashMessage('danger', 'You do not have permission to edit this task.');
            header("Location: tasks.php");
            exit();
        }
        
        // Display edit task form
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="display-5 fw-bold" style="letter-spacing: -0.5px; text-decoration: none;" data-aos="fade-right">Edit Task</h1>
                <a href="tasks.php" class="btn btn-pill" data-aos="fade-left">
                    <i class="fas fa-arrow-left"></i> Back to Tasks
                </a>
            </div>
            
            <div class="card" data-aos="fade-up" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;">
                <div class="card-body" style="background-color: #000000; color: #ffffff;">
                    <form method="POST" action="tasks.php" id="taskForm">
                        <input type="hidden" name="task_id" value="<?php echo $task_data['task_id']; ?>">
                        
                        <div class="mb-3">
                            <label for="title" class="form-label" style="color: #ffffff;">Task Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo htmlspecialchars($task_data['title']); ?>" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                        </div>
                        
                        <div class="mb-3">
                            <label for="description" class="form-label" style="color: #ffffff;">Description</label>
                            <textarea class="form-control" id="description" name="description" rows="3" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;"><?php echo htmlspecialchars($task_data['description'] ?? ''); ?></textarea>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-3 mb-3">
                                <label for="category_id" class="form-label" style="color: #ffffff;">Category <span class="text-danger">*</span></label>
                                <select class="form-select" id="category_id" name="category_id" required style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                    <?php foreach ($categories as $category): ?>
                                        <option value="<?php echo $category['category_id']; ?>" <?php echo ($category['category_id'] == $task_data['category_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($category['category_name']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="status" class="form-label" style="color: #ffffff;">Status</label>
                                <select class="form-select" id="status" name="status" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                    <option value="pending" <?php echo ($task_data['status'] == 'pending') ? 'selected' : ''; ?>>Pending</option>
                                    <option value="in_progress" <?php echo ($task_data['status'] == 'in_progress') ? 'selected' : ''; ?>>In Progress</option>
                                    <option value="completed" <?php echo ($task_data['status'] == 'completed') ? 'selected' : ''; ?>>Completed</option>
                                </select>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="priority" class="form-label" style="color: #ffffff;">Priority</label>
                                <select class="form-select" id="priority" name="priority" style="background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                                    <option value="low" <?php echo ($task_data['priority'] == 'low') ? 'selected' : ''; ?>>Low</option>
                                    <option value="medium" <?php echo ($task_data['priority'] == 'medium') ? 'selected' : ''; ?>>Medium</option>
                                    <option value="high" <?php echo ($task_data['priority'] == 'high') ? 'selected' : ''; ?>>High</option>
                                </select>
                            </div>

                            <div class="col-md-3 mb-3">
                                <label for="due_date" class="form-label" style="color: #ffffff;">Due Date</label>
                                <div class="position-relative">
                                    <input type="date" class="form-control" id="due_date" name="due_date" value="<?php echo $task_data['due_date'] ?? ''; ?>" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding-right: 40px;">
                                    <div class="position-absolute" style="right: 10px; top: 50%; transform: translateY(-50%); pointer-events: none;">
                                        <i class="fas fa-calendar-alt" style="color: #8e8e8e;"></i>
                                    </div>
                                    <div class="position-absolute" style="right: 0; top: 0; width: 100%; height: 100%; cursor: pointer;" onclick="document.getElementById('due_date').showPicker()"></div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                            <button type="submit" name="update_task" class="btn btn-pill">
                                <i class="fas fa-save me-2"></i>Update Task
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
<?php
break;

case 'list':
default:
    // Get filter parameters
    $filter_status = $_GET['status'] ?? '';
    $filter_priority = $_GET['priority'] ?? '';
    $filter_category = $_GET['category'] ?? '';
    
    // Get tasks based on filters
    if ($user->isAdmin()) {
        $tasks = $task->getAllTasks($filter_status, $filter_priority, $filter_category);
        $pending_count = $task->countTasksByStatus('pending');
        $in_progress_count = $task->countTasksByStatus('in_progress');
        $completed_count = $task->countTasksByStatus('completed');
    } else {
        $tasks = $task->getTasksByUser($_SESSION['user_id'], $filter_status, $filter_priority, $filter_category);
        $pending_count = $task->countTasksByStatus('pending', $_SESSION['user_id']);
        $in_progress_count = $task->countTasksByStatus('in_progress', $_SESSION['user_id']);
        $completed_count = $task->countTasksByStatus('completed', $_SESSION['user_id']);
    }
    
    // Set the filter label
    $filter_label = 'All Tasks';
    if ($filter_status == 'pending') {
        $filter_label = 'Pending Tasks';
    } elseif ($filter_status == 'in_progress') {
        $filter_label = 'In Progress Tasks';
    } elseif ($filter_status == 'completed') {
        $filter_label = 'Completed Tasks';
    }
    
    // Display task list
    ?>
    <div class="container-fluid py-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="display-5 fw-bold mb-0" style="letter-spacing: -0.5px; text-decoration: none;" data-aos="fade-right">Task Management</h1>
            <a href="tasks.php?action=add" class="btn btn-pill">
                <i class="fas fa-plus-circle"></i>New Task
            </a>
        </div>

        <div class="card" style="background-color: #101010; color: #ffffff; border: 1px solid #333333; border-radius: 12px;" data-aos="fade-up">
            <div class="card-header d-flex justify-content-between align-items-center" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; padding: 20px;">
                <h5 class="mb-0" style="color: #ffffff; font-size: 18px;"><?php echo $filter_label; ?></h5>
                <div class="d-flex gap-3 align-items-center">
                    <!-- Live Search Form -->
                    <div class="search-container" style="position: relative;">
                        <input type="text" id="taskSearch" class="form-control" placeholder="Search tasks..." style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding-left: 35px; width: 250px; border-radius: 24px;">
                        <i class="fas fa-search" style="position: absolute; left: 12px; top: 50%; transform: translateY(-50%); color: #ffffff;"></i>
                    </div>
                    
                    <div class="dropdown">
                        <button class="btn btn-sm btn-pill dropdown-toggle" type="button" id="filterDropdown" data-bs-toggle="dropdown" aria-expanded="false" style="padding: 8px 16px !important; background-color: #000000; color: #ffffff; border: 1px solid #333333;">
                            <i class="fas fa-filter" style="color: #ffffff;"></i> Filter
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end" style="background-color: #000000; border: 1px solid #333333;">
                            <li><a class="dropdown-item <?php echo empty($filter_status) ? 'active' : ''; ?>" href="tasks.php" style="color: #ffffff;">All Tasks</a></li>
                            <li><a class="dropdown-item <?php echo $filter_status == 'pending' ? 'active' : ''; ?>" href="tasks.php?status=pending&priority=<?php echo $filter_priority; ?>&category=<?php echo $filter_category; ?>" style="color: #ffffff;">Pending</a></li>
                            <li><a class="dropdown-item <?php echo $filter_status == 'in_progress' ? 'active' : ''; ?>" href="tasks.php?status=in_progress&priority=<?php echo $filter_priority; ?>&category=<?php echo $filter_category; ?>" style="color: #ffffff;">In Progress</a></li>
                            <li><a class="dropdown-item <?php echo $filter_status == 'completed' ? 'active' : ''; ?>" href="tasks.php?status=completed&priority=<?php echo $filter_priority; ?>&category=<?php echo $filter_category; ?>" style="color: #ffffff;">Completed</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="card-body" style="background-color: #000000; color: #ffffff;">
                <?php if (empty($tasks)): ?>
                    <p class="text-center py-4" style="color: #8e8e8e;">No tasks found. <a href="tasks.php?action=add" style="color: #ffffff; text-decoration: none;">Create your first task!</a></p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover" style="background-color: #000000; color: #ffffff; border-color: #333333;">
                            <thead>
                                <tr>
                                    <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">TITLE</th>
                                    <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">CATEGORY</th>
                                    <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">STATUS</th>
                                    <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">PRIORITY</th>
                                    <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">DUE DATE</th>
                                    <th class="py-3" style="background-color: #000000; color: #ffffff; border-bottom: 1px solid #333333; font-size: 14px; font-weight: 600; text-transform: uppercase;">ACTIONS</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($tasks as $t): ?>
                                    <tr data-task-id="<?php echo $t['task_id']; ?>">
                                        <td style="color: #ffffff; font-size: 16px;"><?php echo htmlspecialchars($t['title']); ?></td>
                                        <td style="color: #ffffff; font-size: 16px;">
                                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 12px; border-radius: 24px;">
                                                <?php echo htmlspecialchars($t['category_name']); ?>
                                            </span>
                                        </td>
                                        <td style="color: #ffffff; font-size: 16px;">
                                            <?php if ($t['status'] === 'pending'): ?>
                                                <span class="badge status-badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 12px; border-radius: 24px;" data-task-id="<?php echo $t['task_id']; ?>" data-status="pending">Pending</span>
                                            <?php elseif ($t['status'] === 'in_progress'): ?>
                                                <span class="badge status-badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 12px; border-radius: 24px;" data-task-id="<?php echo $t['task_id']; ?>" data-status="in_progress">In progress</span>
                                            <?php else: ?>
                                                <span class="badge status-badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 12px; border-radius: 24px;" data-task-id="<?php echo $t['task_id']; ?>" data-status="completed">Completed</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="color: #ffffff; font-size: 16px;">
                                            <span class="badge" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; padding: 8px 12px; border-radius: 24px;">
                                                <?php echo ucfirst($t['priority']); ?>
                                            </span>
                                        </td>
                                        <td style="color: #ffffff; font-size: 16px;">
                                            <?php 
                                            if (!empty($t['due_date'])) {
                                                $due_date = new DateTime($t['due_date']);
                                                echo $due_date->format('M d, Y');
                                            } else {
                                                echo '<span style="color: #8e8e8e;">Not set</span>';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <div class="status-dropdown" data-bs-toggle="tooltip" title="Change Status">
                                                    <button class="btn btn-pill btn-sm status-btn" type="button" data-task-id="<?php echo $t['task_id']; ?>" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; width: 40px; height: 40px; display: inline-flex; align-items: center; justify-content: center; position: relative;">
                                                        <i class="fas fa-tasks" style="color: #ffffff;"></i>
                                                    </button>
                                                    <div class="status-menu" id="statusMenu<?php echo $t['task_id']; ?>" style="display: none; position: absolute; background-color: #000000; border: 1px solid #333333; min-width: 180px; z-index: 1050; border-radius: 8px; box-shadow: 0 4px 8px rgba(0,0,0,0.2); margin-top: 5px; left: 0;">
                                                        <div style="padding: 8px 12px; color: #8e8e8e; border-bottom: 1px solid #333333; font-weight: bold;">Change Status</div>
                                                        <a class="status-option <?php echo $t['status'] === 'pending' ? 'active' : ''; ?>" href="#" data-task-id="<?php echo $t['task_id']; ?>" data-status="pending" style="display: block; padding: 8px 12px; color: #ffffff; text-decoration: none; <?php echo $t['status'] === 'pending' ? 'background-color: #333333;' : ''; ?>">
                                                            <i class="fas fa-clock me-2" style="color: #ffffff;"></i>Pending
                                                        </a>
                                                        <a class="status-option <?php echo $t['status'] === 'in_progress' ? 'active' : ''; ?>" href="#" data-task-id="<?php echo $t['task_id']; ?>" data-status="in_progress" style="display: block; padding: 8px 12px; color: #ffffff; text-decoration: none; <?php echo $t['status'] === 'in_progress' ? 'background-color: #333333;' : ''; ?>">
                                                            <i class="fas fa-spinner me-2" style="color: #ffffff;"></i>In Progress
                                                        </a>
                                                        <a class="status-option <?php echo $t['status'] === 'completed' ? 'active' : ''; ?>" href="#" data-task-id="<?php echo $t['task_id']; ?>" data-status="completed" style="display: block; padding: 8px 12px; color: #ffffff; text-decoration: none; <?php echo $t['status'] === 'completed' ? 'background-color: #333333;' : ''; ?>">
                                                            <i class="fas fa-check-circle me-2" style="color: #ffffff;"></i>Completed
                                                        </a>
                                                    </div>
                                                </div>
                                                <a href="tasks.php?action=view&id=<?php echo $t['task_id']; ?>" class="btn btn-pill btn-sm" data-bs-toggle="tooltip" title="View" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; width: 40px; height: 40px; display: inline-flex; align-items: center; justify-content: center;">
                                                    <i class="fas fa-eye" style="color: #ffffff;"></i>
                                                </a>
                                                <a href="tasks.php?action=edit&id=<?php echo $t['task_id']; ?>" class="btn btn-pill btn-sm" data-bs-toggle="tooltip" title="Edit" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; width: 40px; height: 40px; display: inline-flex; align-items: center; justify-content: center;">
                                                    <i class="fas fa-edit" style="color: #ffffff;"></i>
                                                </a>
                                                <form method="POST" action="tasks.php" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this task?');">
                                                    <input type="hidden" name="task_id" value="<?php echo $t['task_id']; ?>">
                                                    <button type="submit" name="delete_task" class="btn btn-pill btn-sm" data-bs-toggle="tooltip" title="Delete" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; border-radius: 24px; width: 40px; height: 40px; display: inline-flex; align-items: center; justify-content: center;">
                                                        <i class="fas fa-trash-alt" style="color: #ffffff;"></i>
                                                    </button>
                                                </form>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
    break;
}

// Include the footer
require_once 'includes/footer.php';

// End output buffering and flush
ob_end_flush();
?>
<script>
    // Function to immediately update the status badge when dropdown changes
    function updateStatusImmediately(selectElement, taskId) {
        // Get the selected value
        const selectedStatus = selectElement.value;
        console.log(`Updating task ${taskId} to status: ${selectedStatus}`);
        
        // Store the original status in case we need to revert
        const originalStatus = selectElement.getAttribute('data-current-status');
        console.log(`Original status was: ${originalStatus}`);
        
        // First update the UI immediately
        const card = selectElement.closest('.card');
        if (card) {
            // Find the status badge in this card
            const statusBadge = card.querySelector('.status-badge');
            if (statusBadge) {
                // Update the badge immediately
                statusBadge.setAttribute('data-status', selectedStatus);
                // Remove all possible status classes
                statusBadge.classList.remove('bg-secondary', 'bg-info', 'bg-success', 'bg-warning', 'text-dark', 'text-white');
                
                if (selectedStatus === 'pending') {
                    statusBadge.classList.add('bg-secondary');
                    statusBadge.textContent = 'Pending';
                } else if (selectedStatus === 'in_progress') {
                    statusBadge.classList.add('bg-warning', 'text-dark');
                    statusBadge.textContent = 'In progress';
                } else if (selectedStatus === 'completed') {
                    statusBadge.classList.add('bg-success', 'text-white');
                    statusBadge.textContent = 'Completed';
                }
            }
        }
        
        // Update the data-current-status attribute to reflect the new selection
        selectElement.setAttribute('data-current-status', selectedStatus);
        
        // Then make the AJAX call to update the database
        updateTaskStatusAjax(selectElement, taskId);
    }
    
    document.addEventListener('DOMContentLoaded', function() {
        // Task search functionality - real-time filtering as you type
        const searchInput = document.getElementById('taskSearch');
        if (searchInput) {
            searchInput.addEventListener('keyup', function() {
                const searchTerm = this.value.toLowerCase();
                const taskRows = document.querySelectorAll('tbody tr');
                let visibleCount = 0;
                
                taskRows.forEach(function(row) {
                    const title = row.querySelector('td:first-child').textContent.toLowerCase();
                    const category = row.querySelector('td:nth-child(2)').textContent.toLowerCase();
                    const status = row.querySelector('td:nth-child(3)').textContent.toLowerCase();
                    const priority = row.querySelector('td:nth-child(4)').textContent.toLowerCase();
                    const dueDate = row.querySelector('td:nth-child(5)').textContent.toLowerCase();
                    
                    if (title.includes(searchTerm) || category.includes(searchTerm) || 
                        status.includes(searchTerm) || priority.includes(searchTerm) ||
                        dueDate.includes(searchTerm)) {
                        row.style.display = '';
                        visibleCount++;
                    } else {
                        row.style.display = 'none';
                    }
                });
                
                // Show a message if no tasks match the search
                const tableBody = document.querySelector('tbody');
                let noResultsRow = document.getElementById('noSearchResults');
                
                if (visibleCount === 0 && searchTerm !== '') {
                    if (!noResultsRow) {
                        noResultsRow = document.createElement('tr');
                        noResultsRow.id = 'noSearchResults';
                        const cell = document.createElement('td');
                        cell.colSpan = 6; // Span all columns
                        cell.style.textAlign = 'center';
                        cell.style.padding = '20px';
                        cell.style.color = '#8e8e8e';
                        cell.innerHTML = 'No tasks matching <strong>"' + searchTerm + '"</strong>';
                        noResultsRow.appendChild(cell);
                        tableBody.appendChild(noResultsRow);
                    } else {
                        const cell = noResultsRow.querySelector('td');
                        cell.innerHTML = 'No tasks matching <strong>"' + searchTerm + '"</strong>';
                        noResultsRow.style.display = '';
                    }
                } else if (noResultsRow) {
                    noResultsRow.style.display = 'none';
                }
            });
            
            // Focus the search input when the page loads
            searchInput.focus();
        }
        
        // Task filter functionality
        const filterSelect = document.getElementById('taskFilter');
        if (filterSelect) {
            filterSelect.addEventListener('change', function() {
                const filterValue = this.value;
                const taskRows = document.querySelectorAll('tbody tr');
                
                taskRows.forEach(function(row) {
                    if (filterValue === 'all') {
                        row.style.display = '';
                    } else {
                        const statusCell = row.querySelector('td:nth-child(3)');
                        const statusText = statusCell.textContent.trim().toLowerCase().replace(' ', '_');
                        
                        if (statusText.includes(filterValue)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    }
                });
            });
        }
        
        // Initialize Bootstrap dropdowns
        var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'));
        var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
            return new bootstrap.Dropdown(dropdownToggleEl, {
                autoClose: true,
                boundary: 'viewport',
                reference: 'toggle',
                display: 'dynamic'
            });
        });
        
        // Force show dropdown on click
        document.querySelectorAll('.dropdown-toggle').forEach(function(element) {
            element.addEventListener('click', function() {
                var dropdownMenu = this.nextElementSibling;
                if (dropdownMenu && !dropdownMenu.classList.contains('show')) {
                    var dropdown = bootstrap.Dropdown.getInstance(this);
                    if (dropdown) {
                        dropdown.show();
                    } else {
                        var newDropdown = new bootstrap.Dropdown(this);
                        newDropdown.show();
                    }
                }
            });
        });
        
        // Make sure dropdown items are clickable
        document.querySelectorAll('.dropdown-item').forEach(function(item) {
            item.addEventListener('click', function(e) {
                e.stopPropagation();
                this.closest('form').submit();
            });
        });
        
        // Function to update task status using AJAX - updates immediately without page refresh
        function updateTaskStatusAjax(selectElement, taskId) {
            // Get the selected value
            const selectedStatus = selectElement.value;
            console.log(`Updating task ${taskId} to status: ${selectedStatus}`);
            
            // Update the hidden input in the fallback form
            const statusInput = document.getElementById('statusInput' + taskId);
            if (statusInput) {
                statusInput.value = selectedStatus;
            }
            
            // Create form data for the AJAX request
            const formData = new FormData();
            formData.append('ajax_status_update', '1');
            formData.append('task_id', taskId);
            formData.append('status', selectedStatus);
            
            // Show a small loading indicator
            const loadingIndicator = document.createElement('span');
            loadingIndicator.className = 'ms-2 spinner-border spinner-border-sm';
            loadingIndicator.setAttribute('role', 'status');
            loadingIndicator.innerHTML = '<span class="visually-hidden">Loading...</span>';
            selectElement.parentNode.appendChild(loadingIndicator);
            
            // Make the AJAX request
            fetch('tasks.php', {
                method: 'POST',
                body: formData,
                headers: {
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                },
                cache: 'no-store'
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error(`HTTP error! Status: ${response.status}`);
                }
                return response.json();
            })
            .then(data => {
                // Remove loading indicator
                if (loadingIndicator) loadingIndicator.remove();
                
                if (data.success) {
                    console.log('Status updated successfully in database:', data);
                    
                    // Force update all status badges with this task ID
                    forceUpdateAllStatusBadges(taskId, selectedStatus);
                    
                    // Update task progress counts and chart
                    updateTaskProgressCounts();
                    
                    // Add a small checkmark to indicate success
                    const successIndicator = document.createElement('span');
                    successIndicator.className = 'ms-2 text-success';
                    successIndicator.innerHTML = '<i class="fas fa-check"></i>';
                    selectElement.parentNode.appendChild(successIndicator);
                    setTimeout(() => {
                        if (successIndicator) successIndicator.remove();
                    }, 2000);
                    
                    // Update all other dropdowns for this task to match
                    document.querySelectorAll(`.status-select[data-task-id="${taskId}"]`).forEach(dropdown => {
                        if (dropdown !== selectElement) {
                            dropdown.value = selectedStatus;
                            dropdown.setAttribute('data-current-status', selectedStatus);
                        }
                    });
                } else {
                    console.error('Error updating status:', data.message);
                    alert('Failed to update status: ' + data.message);
                    // Submit the form as fallback
                    document.getElementById('statusForm' + taskId).submit();
                }
            })
            .catch(error => {
                // Remove loading indicator
                if (loadingIndicator) loadingIndicator.remove();
                
                console.error('Error:', error);
                alert('Network error. Submitting form instead.');
                // Fallback to form submission if AJAX fails
                document.getElementById('statusForm' + taskId).submit();
            });
        }
        
        // Function to force update all status badges for a task
        function forceUpdateAllStatusBadges(taskId, newStatus) {
            console.log('Updating badges for task ID:', taskId, 'to status:', newStatus);
            
            // Get all badges with data-task-id attribute matching this task
            document.querySelectorAll(`[data-task-id="${taskId}"]`).forEach(element => {
                console.log('Found element with matching task ID:', element);
                
                // Check if this is a badge or contains badges
                if (element.classList.contains('badge')) {
                    updateBadgeStatus(element, newStatus);
                } else {
                    // Look for badges inside this element
                    element.querySelectorAll('.badge').forEach(badge => {
                        console.log('Checking badge inside container:', badge);
                        const badgeText = badge.textContent.trim().toLowerCase();
                        if (badgeText === 'pending' || badgeText === 'in progress' || badgeText === 'completed') {
                            updateBadgeStatus(badge, newStatus);
                        }
                    });
                }
            });
            
            // Also directly target all status badges by class
            document.querySelectorAll('.status-badge').forEach(badge => {
                console.log('Found status badge:', badge);
                const badgeTaskId = badge.getAttribute('data-task-id');
                if (badgeTaskId === taskId.toString()) {
                    updateBadgeStatus(badge, newStatus);
                }
            });
            
            // Special handling for the task view badge
            const taskViewBadge = document.querySelector('.task-status-badge');
            if (taskViewBadge) {
                console.log('Found task view badge:', taskViewBadge);
                updateBadgeStatus(taskViewBadge, newStatus);
            }
        }
        
        // Helper function to update a badge's status
        function updateBadgeStatus(badge, newStatus) {
            console.log('Updating badge:', badge, 'to status:', newStatus);
            
            // Update data-status attribute
            badge.setAttribute('data-status', newStatus);
            
            // Remove all possible status classes
            badge.classList.remove('bg-secondary', 'bg-info', 'bg-success', 'bg-warning', 'text-dark', 'text-white');
            
            // Add new status class and update text
            if (newStatus === 'pending') {
                badge.classList.add('bg-secondary');
                badge.textContent = 'Pending';
            } else if (newStatus === 'in_progress') {
                badge.classList.add('bg-warning', 'text-dark');
                badge.textContent = 'In progress';
            } else if (newStatus === 'completed') {
                badge.classList.add('bg-success', 'text-white');
                badge.textContent = 'Completed';
            }
        }
        
        // Function to ensure the page shows the correct status on load
        document.addEventListener('DOMContentLoaded', function() {
            // Synchronize all dropdowns with their data-current-status
            document.querySelectorAll('.status-select').forEach(dropdown => {
                const currentStatus = dropdown.getAttribute('data-current-status');
                if (currentStatus) {
                    dropdown.value = currentStatus;
                    console.log(`Set dropdown for task ${dropdown.getAttribute('data-task-id')} to ${currentStatus}`);
                }
                
                // Also sync any badges in the same card
                const card = dropdown.closest('.card');
                if (card) {
                    const badge = card.querySelector('.status-badge');
                    if (badge && currentStatus) {
                        updateBadgeStatus(badge, currentStatus);
                    }
                }
            });
        });
        
        // Function to update all status badges for a specific task
        function updateAllTaskStatusBadges(taskId, newStatus) {
            // Directly find all status badges for this task using the data-task-id attribute
            const statusBadges = document.querySelectorAll(`.status-badge[data-task-id="${taskId}"]`);
            
            // Update each badge
            statusBadges.forEach(badge => {
                // Update the data-status attribute
                badge.setAttribute('data-status', newStatus);
                
                // Remove old status classes
                badge.classList.remove('bg-secondary', 'bg-info', 'bg-success');
                
                // Add new status class and update text
                if (newStatus === 'pending') {
                    badge.classList.add('bg-secondary');
                    badge.textContent = 'Pending';
                } else if (newStatus === 'in_progress') {
                    badge.classList.add('bg-info');
                    badge.textContent = 'In progress';
                } else if (newStatus === 'completed') {
                    badge.classList.add('bg-success');
                    badge.textContent = 'Completed';
                }
            });
            
            // Also update any other badges that might not have the status-badge class
            const allTaskElements = document.querySelectorAll(`[data-task-id="${taskId}"]`);
            allTaskElements.forEach(element => {
                if (element.classList.contains('badge') && !element.classList.contains('status-badge')) {
                    const text = element.textContent.trim().toLowerCase();
                    if (text === 'pending' || text === 'in progress' || text === 'completed') {
                        // Remove old status classes
                        element.classList.remove('bg-secondary', 'bg-info', 'bg-success');
                        
                        // Add new status class and update text
                        if (newStatus === 'pending') {
                            element.classList.add('bg-secondary');
                            element.textContent = 'Pending';
                        } else if (newStatus === 'in_progress') {
                            element.classList.add('bg-info');
                            element.textContent = 'In progress';
                        } else if (newStatus === 'completed') {
                            element.classList.add('bg-success');
                            element.textContent = 'Completed';
                        }
                    }
                }
            });
        }
        
        // Function to update task progress counts and chart
        function updateTaskProgressCounts() {
            // Count tasks by status
            const pendingCount = document.querySelectorAll('.badge.bg-secondary:not(.priority-badge)').length;
            const inProgressCount = document.querySelectorAll('.badge.bg-info:not(.priority-badge)').length;
            const completedCount = document.querySelectorAll('.badge.bg-success:not(.priority-badge)').length;
            
            // Update the counts in the progress section
            const pendingCountElement = document.getElementById('pendingCount');
            const inProgressCountElement = document.getElementById('inProgressCount');
            const completedCountElement = document.getElementById('completedCount');
            
            if (pendingCountElement) pendingCountElement.textContent = pendingCount;
            if (inProgressCountElement) inProgressCountElement.textContent = inProgressCount;
            if (completedCountElement) completedCountElement.textContent = completedCount;
            
            // Update the progress chart if it exists
            if (typeof updateProgressChart === 'function') {
                updateProgressChart(pendingCount, inProgressCount, completedCount);
            }
        }
        
        // Style the select dropdowns
        document.querySelectorAll('.direct-dropdown select').forEach(function(select) {
            // Add custom styling if needed
            select.style.cursor = 'pointer';
        });
        
        // Add data-task-id attribute to all task cards for easier selection
        document.querySelectorAll('.card').forEach(function(card) {
            const statusSelect = card.querySelector('.status-select');
            if (statusSelect && statusSelect.dataset.taskId) {
                card.setAttribute('data-task-id', statusSelect.dataset.taskId);
            }
        });
        // Custom status dropdown implementation
        document.querySelectorAll('.status-btn').forEach(function(button) {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const taskId = this.getAttribute('data-task-id');
                const menuId = 'statusMenu' + taskId;
                const menu = document.getElementById(menuId);
                
                // Close all other dropdowns first
                document.querySelectorAll('.status-menu').forEach(function(m) {
                    if (m.id !== menuId) {
                        m.style.display = 'none';
                    }
                });
                
                // Toggle this dropdown
                if (menu.style.display === 'block') {
                    menu.style.display = 'none';
                } else {
                    menu.style.display = 'block';
                }
            });
        });
        
        // Close dropdowns when clicking outside
        document.addEventListener('click', function(e) {
            if (!e.target.closest('.status-dropdown')) {
                document.querySelectorAll('.status-menu').forEach(function(menu) {
                    menu.style.display = 'none';
                });
            }
        });
        
        // Status change functionality
        document.querySelectorAll('.status-option').forEach(function(item) {
            item.addEventListener('click', function(e) {
                e.preventDefault();
                const taskId = this.dataset.taskId;
                const newStatus = this.dataset.status;
                const statusText = this.textContent.trim();
                
                // Send AJAX request to update task status
                fetch('update_task_status.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: 'task_id=' + taskId + '&status=' + newStatus
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update the status badge in the table
                        const statusBadge = document.querySelector('tr[data-task-id="' + taskId + '"] .status-badge');
                        if (statusBadge) {
                            statusBadge.className = 'badge status-badge';
                            
                            if (newStatus === 'pending') {
                                statusBadge.classList.add('bg-secondary');
                                statusBadge.textContent = 'Pending';
                            } else if (newStatus === 'in_progress') {
                                statusBadge.classList.add('bg-info');
                                statusBadge.textContent = 'In Progress';
                            } else if (newStatus === 'completed') {
                                statusBadge.classList.add('bg-success');
                                statusBadge.textContent = 'Completed';
                            }
                        }
                        
                        // Update all other instances of this task's status
                        updateAllTaskStatusBadges(taskId, newStatus);
                        
                        // Update the dropdown button to show active status
                        const dropdownItems = document.querySelectorAll('.status-item[data-task-id="' + taskId + '"]');
                        dropdownItems.forEach(item => {
                            item.classList.remove('active');
                            if (item.dataset.status === newStatus) {
                                item.classList.add('active');
                            }
                        });
                        
                        // Status updated silently without showing a toast notification
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
            });
        });
    });
</script>



<?php
// Include the footer
require_once 'includes/footer.php';

// Flush the output buffer and send the content to the browser
ob_end_flush();
?>
