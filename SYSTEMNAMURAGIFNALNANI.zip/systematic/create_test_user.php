<?php
/**
 * Script to create a test user for login testing
 */
require_once 'config/database.php';
require_once 'includes/user.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Initialize user object
$user = new User($db);

// Test user credentials
$username = 'testuser';
$email = 'test@example.com';
$password = 'password123';
$role_id = 3; // Regular user

try {
    // Hash password
    $password_hash = password_hash($password, PASSWORD_BCRYPT);
    
    // Check if user already exists
    $stmt = $db->prepare("SELECT user_id FROM users WHERE username = ? OR email = ?");
    $stmt->execute([$username, $email]);
    $existing_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existing_user) {
        echo "Test user already exists.<br>";
    } else {
        // Create the test user
        $stmt = $db->prepare("INSERT INTO users (username, email, password, role_id, is_active) VALUES (?, ?, ?, ?, 1)");
        $result = $stmt->execute([$username, $email, $password_hash, $role_id]);
        
        if ($result) {
            echo "Test user created successfully!<br>";
            echo "Username: $username<br>";
            echo "Password: $password<br>";
            echo "You can now log in with these credentials.";
        } else {
            echo "Failed to create test user.";
        }
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>

<p><a href="login.php">Go to Login Page</a></p>
