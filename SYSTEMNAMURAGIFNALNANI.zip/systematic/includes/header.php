<?php
require_once 'includes/session.php';
require_once 'config/database.php';
require_once 'includes/user.php';
require_once 'includes/task.php';
require_once 'includes/log.php';

// Initialize database connection
$database = new Database();
$db = $database->getConnection();

// Initialize user object
$user = new User($db);

// Initialize task object
$task = new Task($db);

// Initialize log object
$log = new Log($db);

// Get flash message if any
$flash = getFlashMessage();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Systematic Task Management</title>
    
    <!-- Custom CSS -->
    <link href="assets/css/custom-framework.css" rel="stylesheet">
    <link href="assets/css/custom-framework-components.css" rel="stylesheet">
    <link href="assets/css/custom-framework-more.css" rel="stylesheet">
    <link href="assets/css/enhanced-ui.css" rel="stylesheet">
    <link href="assets/css/modern-theme.css" rel="stylesheet">
    <link href="assets/css/icon-fixes.css" rel="stylesheet">
    
    <!-- AOS Animation Library (Local) -->
    <link href="assets/css/lib/aos.css" rel="stylesheet">
    
    <!-- Custom CSS -->
    <link href="assets/css/style.css" rel="stylesheet">
    
    <!-- Responsive CSS -->
    <link href="assets/css/responsive.css" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="assets/css/lib/fontawesome.min.css">
    
    <!-- Poppins Font for the entire UI (Local) -->
    <link href="assets/css/lib/poppins.css" rel="stylesheet">
</head>
<body>
    <header class="app-header" style="position: fixed; top: 0; left: 0; right: 0; z-index: 1001;">
        <div class="container-fluid px-4">
            <div class="row align-items-center">
                <div class="col-auto d-lg-none">
                    <button class="sidebar-toggle" type="button" data-toggle="offcanvas" data-target="#sidebar">
                        <i class="fa-solid fa-bars"></i>
                    </button>
                </div>
                <div class="col-auto">
                    <a href="dashboard.php" class="app-logo" data-aos="fade-right">
                        <div class="logo-container">
                            <svg width="40" height="40" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <rect width="32" height="32" rx="6" fill="#000000"/>
                                <path d="M8 10H24M8 16H20M8 22H16" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round"/>
                            </svg>
                            <span style="font-size: 1.6rem; font-weight: 600; margin-left: 15px;">Systematic</span>
                        </div>
                    </a>
                </div>
                <div class="col d-none d-md-block">
                    <nav class="main-nav">
                        <ul class="nav">
                            <li class="nav-item"><a href="dashboard.php" class="nav-link"><i class="fas fa-home"></i> Home</a></li>
                            <li class="nav-item"><a href="tasks.php" class="nav-link"><i class="fas fa-plus-circle"></i> Tasks</a></li>
                            <li class="nav-item"><a href="categories.php" class="nav-link"><i class="fas fa-folder"></i> Categories</a></li>
                            <li class="nav-item"><a href="reports.php" class="nav-link"><i class="fas fa-chart-bar"></i> Reports</a></li>
                        </ul>
                    </nav>
                </div>
                <div class="col-auto ms-auto d-flex align-items-center gap-3">
                    <div class="header-actions d-flex align-items-center gap-3">
                        <?php if (isLoggedIn()): ?>
                            <div class="user-menu-container" id="userMenuContainer" style="position: relative;">
                                <div id="userAvatar" class="user-avatar" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: 48px; height: 48px; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer;">
                                    <span style="font-weight: 600; font-size: 1.3rem; font-family: 'Poppins', sans-serif;"><?php echo substr($_SESSION['username'] ?? 'U', 0, 1); ?></span>
                                </div>
                                <div id="userDropdown" class="user-dropdown" style="display: none; position: absolute; right: 0; top: 50px; background-color: #000000; border: 1px solid #333333; border-radius: 12px; padding: 8px; min-width: 220px; z-index: 1000; box-shadow: 0 4px 8px rgba(0,0,0,0.1);">
                                    <div class="px-3 py-2 mb-2" style="border-bottom: 1px solid #333333;">
                                        <p class="mb-0" style="color: #8e8e8e; font-size: 12px; font-family: 'Poppins', sans-serif;">Signed in as</p>
                                        <p class="mb-0" style="color: #ffffff; font-weight: 600; font-family: 'Poppins', sans-serif;"><?php echo $_SESSION['username'] ?? 'User'; ?></p>
                                    </div>
                                    <a href="profile.php" class="user-dropdown-item" style="color: #ffffff; padding: 8px 16px; border-radius: 8px; font-family: 'Poppins', sans-serif; display: block; text-decoration: none; margin-bottom: 4px;">
                                        <i class="fas fa-user-circle me-2" style="color: #ffffff;"></i> Profile
                                    </a>
                                    <?php if ($_SESSION['role'] === 'admin'): ?>
                                    <a href="settings.php" class="user-dropdown-item" style="color: #ffffff; padding: 8px 16px; border-radius: 8px; font-family: 'Poppins', sans-serif; display: block; text-decoration: none; margin-bottom: 4px;">
                                        <i class="fas fa-cog me-2" style="color: #ffffff;"></i> Settings
                                    </a>
                                    <?php endif; ?>
                                    <div style="border-top: 1px solid #333333; margin: 8px 0;"></div>
                                    <a href="logout.php" class="user-dropdown-item" style="color: #ffffff; padding: 8px 16px; border-radius: 8px; font-family: 'Poppins', sans-serif; display: block; text-decoration: none;">
                                        <i class="fas fa-sign-out-alt me-2" style="color: #ffffff;"></i> Logout
                                    </a>
                                </div>
                            </div>
                            </div>
                        <?php else: ?>
                            <div class="d-flex gap-2">
                                <a href="login.php" class="btn" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: auto; padding: 8px 16px;">
                                    <i class="fa-solid fa-sign-in-alt" style="margin-right: 8px;"></i>Login
                                </a>
                                <a href="register.php" class="btn" style="background-color: #000000; color: #ffffff; border: 1px solid #333333; width: auto; padding: 8px 16px;">
                                    <i class="fa-solid fa-user-plus" style="margin-right: 8px;"></i>Register
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
    <?php if (isLoggedIn()): ?>
    <div class="app-container">
        <!-- Sidebar for mobile -->
        <div class="offcanvas offcanvas-start" tabindex="-1" id="sidebar">
            <div class="offcanvas-header" style="background-color: #000000; border-bottom: 1px solid #333333;">
                <h5 class="offcanvas-title" style="color: #ffffff;">
                    <svg width="24" height="24" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg" class="me-2">
                        <rect width="32" height="32" rx="6" fill="#000000"/>
                        <path d="M8 10H24M8 16H20M8 22H16" stroke="#FFFFFF" stroke-width="2.5" stroke-linecap="round"/>
                    </svg>
                    Systematic
                </h5>
                <button type="button" class="btn-close" data-dismiss="offcanvas"></button>
            </div>
            <div class="offcanvas-body" style="background-color: #000000; padding: 0;">
                <div class="sidebar-menu" style="margin-top: 120px;">
                    <ul class="nav flex-column" style="gap: 12px; padding: 0 15px;">
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : ''; ?>" href="dashboard.php" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'border: 1px solid #333333;' : ''; ?>">
                                <i class="fa-solid fa-house me-2" style="color: #ffffff;"></i>
                                Dashboard
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'tasks.php' ? 'active' : ''; ?>" href="tasks.php" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) === 'tasks.php' ? 'border: 1px solid #333333;' : ''; ?>">
                                <i class="fa-solid fa-list-check me-2" style="color: #ffffff;"></i>
                                Tasks
                            </a>
                        </li>
                        <?php if ($_SESSION['role'] === 'admin'): ?>
                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'calendar.php' ? 'active' : ''; ?>" href="calendar.php" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) === 'calendar.php' ? 'border: 1px solid #333333;' : ''; ?>">
                                <i class="fa-solid fa-calendar-days me-2" style="color: #ffffff;"></i>
                                Calendar
                            </a>
                        </li>
                        <?php endif; ?>

                        <li class="nav-item">
                            <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) === 'notes.php' ? 'active' : ''; ?>" href="notes.php" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) === 'notes.php' ? 'border: 1px solid #333333;' : ''; ?>">
                                <i class="fa-solid fa-note-sticky me-2" style="color: #ffffff;"></i>
                                Notes
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        
        <!-- Desktop sidebar -->
        <aside class="sidebar d-none d-lg-block" style="box-shadow: 0 0 15px rgba(0, 0, 0, 0.1); background-color: #000000;">
            <div class="sidebar-menu" style="margin-top: 80px;">
                <ul class="nav flex-column" style="gap: 15px; padding: 0 15px;">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'active' : ''; ?>" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? 'border: 1px solid #333333;' : ''; ?>">
                            <i class="fa-solid fa-gauge-high" style="color: #ffffff; margin-right: 10px;"></i>
                            <span>Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="tasks.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'tasks.php' ? 'active' : ''; ?>" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) == 'tasks.php' ? 'border: 1px solid #333333;' : ''; ?>">
                            <i class="fas fa-plus-circle" style="color: #ffffff; margin-right: 10px;"></i>
                            <span>My Tasks</span>
                        </a>
                    </li>
                    <?php if ($_SESSION['role'] === 'admin'): ?>
                    <li class="nav-item">
                        <a href="users.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'active' : ''; ?>" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) == 'users.php' ? 'border: 1px solid #333333;' : ''; ?>">
                            <i class="fas fa-users" style="color: #ffffff; margin-right: 10px;"></i>
                            <span>Users</span>
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a href="logs.php" class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'logs.php' ? 'active' : ''; ?>" style="color: #ffffff; padding: 12px 15px; border-radius: 8px; <?php echo basename($_SERVER['PHP_SELF']) == 'logs.php' ? 'border: 1px solid #333333;' : ''; ?>">
                            <i class="fa-solid fa-history" style="color: #ffffff; margin-right: 10px;"></i>
                            <span>My Logs</span>
                        </a>
                    </li>
                </ul>
            </div>
        </aside>
        
        <main class="content">
    <?php else: ?>
        <main class="container py-4">
    <?php endif; ?>
        
        <?php if ($flash): ?>
            <div class="alert alert-<?php echo $flash['type']; ?> alert-dismissible fade show" role="alert" data-aos="fade-down" style="margin-top: 50px; margin-bottom: 20px;">
                <?php echo $flash['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>
