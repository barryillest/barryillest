<?php
class Log {
    private $conn;
    
    public function __construct($db) {
        $this->conn = $db;
    }
    
    // Create a log entry
    public function create($user_id, $action, $entity_type, $entity_id, $details = null) {
        try {
            // First, check if the logs table exists, if not create it
            $this->createLogsTableIfNotExists();
            
            $query = "INSERT INTO logs (user_id, action, entity_type, entity_id, details) 
                      VALUES (:user_id, :action, :entity_type, :entity_id, :details)";
            
            $stmt = $this->conn->prepare($query);
            
            // Clean and bind data
            $user_id = htmlspecialchars(strip_tags($user_id));
            $action = htmlspecialchars(strip_tags($action));
            $entity_type = htmlspecialchars(strip_tags($entity_type));
            $entity_id = htmlspecialchars(strip_tags($entity_id));
            $details = $details ? htmlspecialchars(strip_tags($details)) : null;
            
            $stmt->bindParam(':user_id', $user_id);
            $stmt->bindParam(':action', $action);
            $stmt->bindParam(':entity_type', $entity_type);
            $stmt->bindParam(':entity_id', $entity_id);
            $stmt->bindParam(':details', $details);
            
            if($stmt->execute()) {
                return true;
            }
            return false;
        } catch(PDOException $e) {
            // If there's an error, return false
            return false;
        }
    }
    
    // Get logs for a specific user
    public function getUserLogs($user_id, $limit = 100) {
        try {
            // Check if the logs table exists
            if (!$this->checkIfLogsTableExists()) {
                return array();
            }
            
            $query = "SELECT l.*, t.title as task_title 
                      FROM logs l 
                      LEFT JOIN tasks t ON l.entity_type = 'task' AND l.entity_id = t.task_id 
                      WHERE l.user_id = :user_id 
                      ORDER BY l.created_at DESC 
                      LIMIT :limit";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            $stmt->bindParam(':limit', $limit, PDO::PARAM_INT);
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            return array();
        }
    }
    
    // Check if logs table exists
    private function checkIfLogsTableExists() {
        try {
            $query = "SHOW TABLES LIKE 'logs'";
            $stmt = $this->conn->prepare($query);
            $stmt->execute();
            
            return $stmt->rowCount() > 0;
        } catch(PDOException $e) {
            return false;
        }
    }
    
    // Create logs table if it doesn't exist
    private function createLogsTableIfNotExists() {
        try {
            $sql = "CREATE TABLE IF NOT EXISTS logs (
                log_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY,
                user_id INT(11) NOT NULL,
                action VARCHAR(255) NOT NULL,
                entity_type VARCHAR(50) NOT NULL,
                entity_id INT(11) NOT NULL,
                details TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
            
            $this->conn->exec($sql);
            return true;
        } catch(PDOException $e) {
            return false;
        }
    }
    
    // Format log entry for display
    public function formatLogEntry($log) {
        $action = ucfirst($log['action']);
        $entity_type = ucfirst($log['entity_type']);
        $entity_name = '';
        
        if ($log['entity_type'] == 'task' && isset($log['task_title'])) {
            $entity_name = '"' . $log['task_title'] . '"';
        }
        
        $timestamp = date('M j, Y g:i A', strtotime($log['created_at']));
        
        return "$action $entity_type $entity_name - $timestamp";
    }
    
    // Delete a specific log entry
    public function deleteLog($log_id, $user_id) {
        try {
            $query = "DELETE FROM logs WHERE log_id = :log_id AND user_id = :user_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':log_id', $log_id, PDO::PARAM_INT);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            
            return $stmt->execute();
        } catch(PDOException $e) {
            return false;
        }
    }
    
    // Clear all logs for a user
    public function clearAllLogs($user_id) {
        try {
            $query = "DELETE FROM logs WHERE user_id = :user_id";
            
            $stmt = $this->conn->prepare($query);
            $stmt->bindParam(':user_id', $user_id, PDO::PARAM_INT);
            
            return $stmt->execute();
        } catch(PDOException $e) {
            return false;
        }
    }
}
?>
