<?php
/**
 * Task class for task management
 */
class Task {
    private $db;
    private $conn;

    /**
     * Constructor
     * @param mixed $db Database connection or Database object
     */
    public function __construct($db) {
        if ($db instanceof PDO) {
            $this->conn = $db;
        } else {
            // If we received a Database object instead of a PDO connection
            $this->db = $db;
            $this->conn = $db->getConnection();
        }
        
        // Ensure we have a valid connection
        if (!$this->conn) {
            throw new Exception("Database connection could not be established");
        }
    }
    
    /**
     * Get the database connection
     * @return PDO Database connection
     */
    public function getConnection() {
        return $this->conn;
    }
    
    /**
     * Update task status directly (more reliable method)
     * @param int $task_id Task ID
     * @param string $status New status
     * @return bool True if update successful, false otherwise
     */
    public function updateStatus($task_id, $status) {
        try {
            // Direct SQL query for maximum reliability
            $sql = "UPDATE tasks SET status = ? WHERE task_id = ?";
            $stmt = $this->conn->prepare($sql);
            $result = $stmt->execute([$status, $task_id]);
            
            if ($result) {
                // Double-check the update was successful
                $verify = $this->conn->prepare("SELECT status FROM tasks WHERE task_id = ?");
                $verify->execute([$task_id]);
                $updated_status = $verify->fetchColumn();
                
                error_log("Task ID: $task_id - Status updated to: $status, Verified status: $updated_status");
                
                return ($updated_status === $status);
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in updateStatus: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Create a new task
     * @param string $title Task title
     * @param string $description Task description
     * @param int $user_id User ID
     * @param int $category_id Category ID
     * @param string $priority Task priority
     * @param string $due_date Due date (YYYY-MM-DD)
     * @return bool|int Task ID on success, false on failure
     */
    /**
     * Execute a stored procedure (internal method)
     * @param string $procedure Procedure name
     * @param array $params Parameters for the procedure
     * @return array|bool Result set or false on failure
     */
    private function callProcedure($procedure, $params = []) {
        try {
            // If we have a Database object, use its callProcedure method
            if (isset($this->db) && method_exists($this->db, 'callProcedure')) {
                return $this->db->callProcedure($procedure, $params);
            }
            
            // Otherwise, execute the procedure directly with our PDO connection
            $placeholders = implode(',', array_fill(0, count($params), '?'));
            $sql = "CALL $procedure($placeholders)";
            
            // Log the SQL query for debugging
            error_log("Executing SQL: $sql with params: " . print_r($params, true));
            
            $stmt = $this->conn->prepare($sql);
            
            // Handle null values properly
            foreach ($params as $i => $param) {
                $paramType = PDO::PARAM_STR;
                if (is_int($param)) {
                    $paramType = PDO::PARAM_INT;
                } elseif (is_null($param)) {
                    $paramType = PDO::PARAM_NULL;
                }
                $stmt->bindValue($i+1, $param, $paramType);
            }
            
            $stmt->execute();
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error in callProcedure($procedure): " . $e->getMessage());
            return false;
        }
    }

    public function create($title, $description, $user_id, $category_id, $priority = 'medium', $due_date = null) {
        try {
            // First try using the stored procedure
            $result = $this->callProcedure('create_task', [
                $title,
                $description,
                $user_id,
                $category_id,
                $priority,
                $due_date
            ]);
            
            if ($result && isset($result[0]['task_id'])) {
                $task_id = $result[0]['task_id'];
                // Log the task creation
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'created', 'task', $task_id, "Created task: $title");
                }
                return $task_id;
            } else {
                // Log the error for debugging
                error_log("Task creation with stored procedure failed. Falling back to direct query.");
                
                // Fall back to direct query if the stored procedure fails
                $conn = $this->conn;
                $stmt = $conn->prepare("INSERT INTO tasks (title, description, user_id, category_id, priority, due_date) 
                                      VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$title, $description, $user_id, $category_id, $priority, $due_date]);
                
                $task_id = $conn->lastInsertId();
                
                if ($task_id) {
                    // Log the task creation
                    if (class_exists('Log')) {
                        $log = new Log($this->conn);
                        $log->create($user_id, 'created', 'task', $task_id, "Created task: $title");
                    }
                    return $task_id;
                } else {
                    error_log("Direct task insertion failed.");
                }
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in task creation: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Update a task
     * @param int $task_id Task ID
     * @param string $title Task title
     * @param string $description Task description
     * @param int $category_id Category ID
     * @param string $status Task status
     * @param string $priority Task priority
     * @param string $due_date Due date (YYYY-MM-DD)
     * @return bool True if update successful, false otherwise
     */
    public function update($task_id, $title, $description, $category_id, $status, $priority, $due_date) {
        try {
            // Get the user ID for logging
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
            
            // First try using the stored procedure
            $result = $this->callProcedure('update_task', [
                $task_id,
                $title,
                $description,
                $category_id,
                $status,
                $priority,
                $due_date
            ]);
            
            if ($result !== false) {
                // Log the task update
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'updated', 'task', $task_id, "Updated task: $title");
                }
                return true;
            }
            
            // If the stored procedure fails, fall back to a direct query
            error_log("Task update with stored procedure failed. Falling back to direct query.");
            $conn = $this->conn;
            $stmt = $conn->prepare("UPDATE tasks 
                                  SET title = ?, description = ?, category_id = ?, 
                                      status = ?, priority = ?, due_date = ? 
                                  WHERE task_id = ?");
            $success = $stmt->execute([$title, $description, $category_id, $status, $priority, $due_date, $task_id]);
            
            if ($success) {
                // Log the task update
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'updated', 'task', $task_id, "Updated task: $title");
                }
                return true;
            } else {
                error_log("Direct task update failed. Task ID: $task_id");
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in task update: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Delete a task
     * @param int $task_id Task ID
     * @return bool True if deletion successful, false otherwise
     */
    public function delete($task_id) {
        try {
            // Get the user ID for logging
            $user_id = isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0;
            
            // Get task details before deletion for logging
            $task = $this->getTaskById($task_id);
            $task_title = $task ? $task['title'] : 'Unknown task';
            
            // First try using the stored procedure
            $result = $this->callProcedure('delete_task', [$task_id]);
            
            // Check if the stored procedure was successful
            if ($result !== false) {
                // Log the task deletion
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'deleted', 'task', $task_id, "Deleted task: $task_title");
                }
                return true;
            }
            
            // If the stored procedure fails, fall back to a direct query
            error_log("Task deletion with stored procedure failed. Falling back to direct query.");
            $conn = $this->conn;
            $stmt = $conn->prepare("DELETE FROM tasks WHERE task_id = ?");
            $success = $stmt->execute([$task_id]);
            
            if ($success && $stmt->rowCount() > 0) {
                // Log the task deletion
                if (class_exists('Log')) {
                    $log = new Log($this->conn);
                    $log->create($user_id, 'deleted', 'task', $task_id, "Deleted task: $task_title");
                }
                return true;
            } else {
                error_log("Direct task deletion failed. Task ID: $task_id, Rows affected: " . $stmt->rowCount());
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Exception in task deletion: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get all tasks with optional filtering
     * @param string $status Filter by status (pending, in_progress, completed)
     * @param string $priority Filter by priority (low, medium, high)
     * @param string $category_id Filter by category ID
     * @param string $user_id Filter by user ID
     * @return array Array of tasks
     */
    public function getAllTasks($status = '', $priority = '', $category_id = '', $user_id = '') {
        try {
            $conn = $this->conn;
            
            // Build the query with potential filters
            $sql = "SELECT t.*, c.category_name, u.username 
                   FROM tasks t
                   JOIN categories c ON t.category_id = c.category_id
                   JOIN users u ON t.user_id = u.user_id
                   WHERE t.status != 'archived'";
            
            $params = [];
            
            // Add filters if provided
            if (!empty($status)) {
                $sql .= " AND t.status = ?";
                $params[] = $status;
            }
            
            if (!empty($priority)) {
                $sql .= " AND t.priority = ?";
                $params[] = $priority;
            }
            
            if (!empty($category_id)) {
                $sql .= " AND t.category_id = ?";
                $params[] = $category_id;
            }
            
            if (!empty($user_id)) {
                $sql .= " AND t.user_id = ?";
                $params[] = $user_id;
            }
            
            $sql .= " ORDER BY t.due_date ASC, t.priority DESC";
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Exception in getAllTasks: " . $e->getMessage());
            return [];
        }
    }
    
    /**
     * Get tasks by user ID with optional filtering
     * @param int $user_id User ID
     * @param string $status Filter by status (pending, in_progress, completed)
     * @param string $priority Filter by priority (low, medium, high)
     * @param string $category_id Filter by category ID
     * @return array Array of tasks
     */
    public function getTasksByUser($user_id, $status = '', $priority = '', $category_id = '') {
        try {
            // Use the getAllTasks method with user_id filter
            return $this->getAllTasks($status, $priority, $category_id, $user_id);
        } catch (Exception $e) {
            error_log("Exception in getTasksByUser: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get task by ID
     * @param int $task_id Task ID
     * @return array|bool Task data or false if not found
     */
    public function getTaskById($task_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT t.*, c.category_name
                FROM tasks t
                JOIN categories c ON t.category_id = c.category_id
                WHERE t.task_id = ?
            ");
            $stmt->execute([$task_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get all categories
     * @return array Array of categories
     */
    public function getAllCategories() {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("SELECT * FROM categories ORDER BY category_name");
            $stmt->execute();
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Get audit logs for a task
     * @param int $task_id Task ID
     * @return array Array of audit logs
     */
    public function getTaskAuditLogs($task_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT a.*, u.username
                FROM audit_logs a
                LEFT JOIN users u ON a.changed_by = u.user_id
                WHERE a.table_name = 'tasks' AND a.record_id = ?
                ORDER BY a.timestamp DESC
            ");
            $stmt->execute([$task_id]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [];
        }
    }

    /**
     * Count tasks by status
     * @param string $status Status to count (pending, in_progress, completed)
     * @param int $user_id Optional user ID to filter by
     * @return int Number of tasks with the specified status
     */
    public function countTasksByStatus($status, $user_id = null) {
        try {
            $conn = $this->conn;
            $sql = "SELECT COUNT(*) FROM tasks WHERE status = ?";
            $params = [$status];
            
            if (!empty($user_id)) {
                $sql .= " AND user_id = ?";
                $params[] = $user_id;
            }
            
            $stmt = $conn->prepare($sql);
            $stmt->execute($params);
            return (int)$stmt->fetchColumn();
        } catch (Exception $e) {
            error_log("Exception in countTasksByStatus: " . $e->getMessage());
            return 0;
        }
    }
    
    /**
     * Get task statistics
     * @param int $user_id User ID
     * @return array Statistics data
     */
    public function getTaskStatistics($user_id) {
        try {
            $conn = $this->conn;
            $stmt = $conn->prepare("
                SELECT 
                    COUNT(*) as total_tasks,
                    SUM(CASE WHEN status = 'pending' THEN 1 ELSE 0 END) as pending_tasks,
                    SUM(CASE WHEN status = 'in_progress' THEN 1 ELSE 0 END) as in_progress_tasks,
                    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed_tasks,
                    SUM(CASE WHEN due_date < CURDATE() AND status != 'completed' THEN 1 ELSE 0 END) as overdue_tasks
                FROM tasks
                WHERE user_id = ? AND status != 'archived'
            ");
            $stmt->execute([$user_id]);
            return $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            error_log("Database error: " . $e->getMessage());
            return [
                'total_tasks' => 0,
                'pending_tasks' => 0,
                'in_progress_tasks' => 0,
                'completed_tasks' => 0,
                'overdue_tasks' => 0
            ];
        }
    }
}
?>
