    <?php if (isLoggedIn()): ?>
        </main>
    </div> <!-- .app-container -->
    <?php else: ?>
        </main>
    <?php endif; ?>

<!-- Bootstrap JavaScript Bundle with Popper (Local) -->
<script src="assets/js/lib/bootstrap.bundle.min.js"></script>

<!-- Custom JavaScript -->
<script src="assets/js/custom-framework.js"></script>
    
<!-- AOS Animation Library (Local) -->
<script src="assets/js/lib/aos.js"></script>
    
<!-- Custom JS -->
<script src="assets/js/main.js"></script>
    
<script>
    // Initialize AOS
    AOS.init({
        duration: 800,
        once: true
    });
    
    // User avatar dropdown functionality
    document.addEventListener('DOMContentLoaded', function() {
        const userAvatar = document.getElementById('userAvatar');
        const userDropdown = document.getElementById('userDropdown');
        const userMenuContainer = document.getElementById('userMenuContainer');
        
        if (userAvatar && userDropdown) {
            // Toggle dropdown when avatar is clicked
            userAvatar.addEventListener('click', function(e) {
                e.stopPropagation();
                userDropdown.style.display = userDropdown.style.display === 'none' ? 'block' : 'none';
            });
            
            // Close dropdown when clicking outside
            document.addEventListener('click', function(e) {
                if (!userMenuContainer.contains(e.target)) {
                    userDropdown.style.display = 'none';
                }
            });
            
            // Prevent dropdown from closing when clicking inside it
            userDropdown.addEventListener('click', function(e) {
                e.stopPropagation();
            });
        }
    });
    
    // Global search functionality and theme toggle
    document.addEventListener('DOMContentLoaded', function() {
        // Global search
        const globalSearch = document.getElementById('globalSearch');
        if (globalSearch) {
            globalSearch.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    window.location.href = 'tasks.php?search=' + encodeURIComponent(this.value);
                }
            });
        }
        
        // Dashboard search and filter functionality
        const dashboardSearchInput = document.getElementById('dashboardSearchInput');
        const dashboardFilterSelect = document.getElementById('dashboardFilterSelect');
        
        if (dashboardSearchInput && dashboardFilterSelect) {
            // Enable instant search when pressing Enter in the search field
            dashboardSearchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    const searchQuery = this.value.trim();
                    const statusFilter = dashboardFilterSelect.value;
                    let url = 'tasks.php';
                    
                    if (searchQuery || statusFilter) {
                        url += '?';
                        if (searchQuery) {
                            url += 'search=' + encodeURIComponent(searchQuery);
                        }
                        if (statusFilter) {
                            url += (searchQuery ? '&' : '') + 'status=' + encodeURIComponent(statusFilter);
                        }
                    }
                    
                    window.location.href = url;
                }
            });
            
            // Enable instant filtering when changing the dropdown
            dashboardFilterSelect.addEventListener('change', function() {
                const searchQuery = dashboardSearchInput.value.trim();
                const statusFilter = this.value;
                let url = 'tasks.php';
                
                if (searchQuery || statusFilter) {
                    url += '?';
                    if (searchQuery) {
                        url += 'search=' + encodeURIComponent(searchQuery);
                    }
                    if (statusFilter) {
                        url += (searchQuery ? '&' : '') + 'status=' + encodeURIComponent(statusFilter);
                    }
                }
                
                window.location.href = url;
            });
        }
        
        // Theme toggle functionality
        const themeToggle = document.getElementById('theme-toggle');
        const currentTheme = localStorage.getItem('theme') || 'light';
        
        // Set initial theme
        if (currentTheme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
        }
        
        if (themeToggle) {
            themeToggle.addEventListener('click', function() {
                let theme = 'light';
                
                if (document.documentElement.getAttribute('data-theme') !== 'dark') {
                    document.documentElement.setAttribute('data-theme', 'dark');
                    theme = 'dark';
                } else {
                    document.documentElement.setAttribute('data-theme', 'light');
                }
                
                localStorage.setItem('theme', theme);
            });
        }
    });
</script>
</body>
</html>
