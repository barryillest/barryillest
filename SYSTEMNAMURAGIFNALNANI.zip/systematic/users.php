<?php
/**
 * User management page for Task Management System
 */
require_once 'includes/header.php';

// Require admin access
requireAdmin();

// Initialize variables
$action = $_GET['action'] ?? 'list';
$user_id = $_GET['id'] ?? null;

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Create user
    if (isset($_POST['create_user'])) {
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $password = $_POST['password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        $role_id = $_POST['role_id'] ?? 3; // Default to regular user
        
        // Validate input
        $errors = [];
        
        if (empty($username)) {
            $errors[] = 'Username is required.';
        } elseif (strlen($username) < 3 || strlen($username) > 50) {
            $errors[] = 'Username must be between 3 and 50 characters.';
        }
        
        if (empty($email)) {
            $errors[] = 'Email is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }
        
        if (empty($password)) {
            $errors[] = 'Password is required.';
        } elseif (strlen($password) < 6) {
            $errors[] = 'Password must be at least 6 characters long.';
        }
        
        if ($password !== $confirm_password) {
            $errors[] = 'Passwords do not match.';
        }
        
        if (empty($errors)) {
            try {
                // Register user
                $user_id = $user->register($username, $email, $password, $role_id);
                
                if ($user_id) {
                    setFlashMessage('success', 'User created successfully!');
                    header("Location: users.php");
                    exit();
                } else {
                    setFlashMessage('danger', 'Failed to create user. Please try again.');
                }
            } catch (PDOException $e) {
                // Check for duplicate entry
                if ($e->getCode() == 23000) {
                    if (strpos($e->getMessage(), 'username')) {
                        setFlashMessage('danger', 'Username already exists. Please choose another one.');
                    } elseif (strpos($e->getMessage(), 'email')) {
                        setFlashMessage('danger', 'Email already exists. Please use another email.');
                    } else {
                        setFlashMessage('danger', 'User creation failed. Please try again.');
                    }
                } else {
                    setFlashMessage('danger', 'User creation failed. Please try again.');
                }
            }
        } else {
            // Set error messages
            setFlashMessage('danger', implode('<br>', $errors));
        }
        
        // Redirect to refresh the page and show flash message
        header("Location: users.php?action=add");
        exit();
    }
    
    // Update user
    if (isset($_POST['update_user'])) {
        $user_id = $_POST['user_id'] ?? '';
        $username = $_POST['username'] ?? '';
        $email = $_POST['email'] ?? '';
        $role_id = $_POST['role_id'] ?? 3; // Default to regular user
        $is_active = isset($_POST['is_active']) ? 1 : 0;
        
        // Validate input
        $errors = [];
        
        if (empty($username)) {
            $errors[] = 'Username is required.';
        } elseif (strlen($username) < 3 || strlen($username) > 50) {
            $errors[] = 'Username must be between 3 and 50 characters.';
        }
        
        if (empty($email)) {
            $errors[] = 'Email is required.';
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Please enter a valid email address.';
        }
        
        if (empty($errors)) {
            try {
                // Update user
                $result = $user->update($user_id, $username, $email, $role_id, $is_active);
                
                if ($result) {
                    setFlashMessage('success', 'User updated successfully!');
                    header("Location: users.php");
                    exit();
                } else {
                    setFlashMessage('danger', 'Failed to update user. Please try again.');
                }
            } catch (PDOException $e) {
                // Check for duplicate entry
                if ($e->getCode() == 23000) {
                    if (strpos($e->getMessage(), 'username')) {
                        setFlashMessage('danger', 'Username already exists. Please choose another one.');
                    } elseif (strpos($e->getMessage(), 'email')) {
                        setFlashMessage('danger', 'Email already exists. Please use another email.');
                    } else {
                        setFlashMessage('danger', 'User update failed. Please try again.');
                    }
                } else {
                    setFlashMessage('danger', 'User update failed. Please try again.');
                }
            }
        } else {
            // Set error messages
            setFlashMessage('danger', implode('<br>', $errors));
        }
        
        // Redirect to refresh the page and show flash message
        header("Location: users.php?action=edit&id=$user_id");
        exit();
    }
    
    // Reset password
    if (isset($_POST['reset_password'])) {
        $user_id = $_POST['user_id'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        // Validate input
        $errors = [];
        
        if (empty($new_password)) {
            $errors[] = 'New password is required.';
        } elseif (strlen($new_password) < 6) {
            $errors[] = 'New password must be at least 6 characters long.';
        }
        
        if ($new_password !== $confirm_password) {
            $errors[] = 'Passwords do not match.';
        }
        
        if (empty($errors)) {
            try {
                // Update password
                $conn = $db->getConnection();
                $password_hash = password_hash($new_password, PASSWORD_BCRYPT);
                
                $stmt = $conn->prepare("
                    UPDATE users 
                    SET password = ? 
                    WHERE user_id = ?
                ");
                $stmt->execute([$password_hash, $user_id]);
                
                setFlashMessage('success', 'Password reset successfully!');
                header("Location: users.php");
                exit();
            } catch (PDOException $e) {
                setFlashMessage('danger', 'Password reset failed. Please try again.');
            }
        } else {
            // Set error messages
            setFlashMessage('danger', implode('<br>', $errors));
        }
        
        // Redirect to refresh the page and show flash message
        header("Location: users.php?action=reset_password&id=$user_id");
        exit();
    }
    
    // Delete user
    if (isset($_POST['delete_user'])) {
        $user_id = $_POST['user_id'] ?? '';
        
        // Prevent deleting self
        if ($user_id == $_SESSION['user_id']) {
            setFlashMessage('danger', 'You cannot delete your own account.');
            header("Location: users.php");
            exit();
        }
        
        try {
            // Delete user
            $conn = $db->getConnection();
            
            // First, check if user has tasks
            $stmt = $conn->prepare("SELECT COUNT(*) as task_count FROM tasks WHERE user_id = ?");
            $stmt->execute([$user_id]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($result['task_count'] > 0) {
                setFlashMessage('danger', 'Cannot delete user with existing tasks. Please reassign or delete their tasks first.');
                header("Location: users.php");
                exit();
            }
            
            // Delete user
            $stmt = $conn->prepare("DELETE FROM users WHERE user_id = ?");
            $stmt->execute([$user_id]);
            
            setFlashMessage('success', 'User deleted successfully!');
        } catch (PDOException $e) {
            setFlashMessage('danger', 'Failed to delete user. Please try again.');
        }
        
        // Redirect to refresh the page and show flash message
        header("Location: users.php");
        exit();
    }
}

// Get all roles for forms
$roles = $user->getAllRoles();

// Handle different actions
switch ($action) {
    case 'add':
        // Display add user form
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 data-aos="fade-right">Create New User</h1>
                <a href="users.php" class="btn btn-outline-secondary" data-aos="fade-left">
                    <i class="fas fa-arrow-left me-2"></i>Back to Users
                </a>
            </div>
            
            <div class="card" data-aos="fade-up">
                <div class="card-body">
                    <form method="POST" action="users.php" id="userForm">
                        <div class="mb-3">
                            <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="username" name="username" required>
                            </div>
                            <small class="form-text text-muted">Username must be between 3 and 50 characters.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="password" class="form-label">Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="password" name="password" required>
                            </div>
                            <small class="form-text text-muted">Password must be at least 6 characters long.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="role_id" class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" id="role_id" name="role_id" required>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?php echo $role['role_id']; ?>">
                                        <?php echo htmlspecialchars($role['role_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <button type="submit" name="create_user" class="btn btn-primary">
                                <i class="fas fa-user-plus me-2"></i>Create User
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
        break;
        
    case 'edit':
        // Get user data
        $user_data = $user->getUserById($user_id);
        
        if (!$user_data) {
            setFlashMessage('danger', 'User not found.');
            header("Location: users.php");
            exit();
        }
        
        // Display edit user form
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 data-aos="fade-right">Edit User</h1>
                <a href="users.php" class="btn btn-outline-secondary" data-aos="fade-left">
                    <i class="fas fa-arrow-left me-2"></i>Back to Users
                </a>
            </div>
            
            <div class="card" data-aos="fade-up">
                <div class="card-body">
                    <form method="POST" action="users.php" id="userForm">
                        <input type="hidden" name="user_id" value="<?php echo $user_data['user_id']; ?>">
                        
                        <div class="mb-3">
                            <label for="username" class="form-label">Username <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-user"></i></span>
                                <input type="text" class="form-control" id="username" name="username" value="<?php echo htmlspecialchars($user_data['username']); ?>" required>
                            </div>
                            <small class="form-text text-muted">Username must be between 3 and 50 characters.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="email" class="form-label">Email <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-envelope"></i></span>
                                <input type="email" class="form-control" id="email" name="email" value="<?php echo htmlspecialchars($user_data['email']); ?>" required>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label for="role_id" class="form-label">Role <span class="text-danger">*</span></label>
                            <select class="form-select" id="role_id" name="role_id" required>
                                <?php foreach ($roles as $role): ?>
                                    <option value="<?php echo $role['role_id']; ?>" <?php echo ($role['role_id'] == $user_data['role_id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($role['role_name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <div class="mb-3 form-check">
                            <input type="checkbox" class="form-check-input" id="is_active" name="is_active" <?php echo $user_data['is_active'] ? 'checked' : ''; ?>>
                            <label class="form-check-label" for="is_active">Active Account</label>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="users.php?action=reset_password&id=<?php echo $user_data['user_id']; ?>" class="btn btn-warning me-md-2">
                                <i class="fas fa-key me-2"></i>Reset Password
                            </a>
                            <button type="submit" name="update_user" class="btn btn-primary">
                                <i class="fas fa-save me-2"></i>Update User
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
        break;
        
    case 'reset_password':
        // Get user data
        $user_data = $user->getUserById($user_id);
        
        if (!$user_data) {
            setFlashMessage('danger', 'User not found.');
            header("Location: users.php");
            exit();
        }
        
        // Display reset password form
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 data-aos="fade-right">Reset Password</h1>
                <a href="users.php" class="btn btn-outline-secondary" data-aos="fade-left">
                    <i class="fas fa-arrow-left me-2"></i>Back to Users
                </a>
            </div>
            
            <div class="card" data-aos="fade-up">
                <div class="card-body">
                    <p class="alert alert-info">
                        <i class="fas fa-info-circle me-2"></i>
                        You are resetting the password for user: <strong><?php echo htmlspecialchars($user_data['username']); ?></strong>
                    </p>
                    
                    <form method="POST" action="users.php" id="passwordForm">
                        <input type="hidden" name="user_id" value="<?php echo $user_data['user_id']; ?>">
                        
                        <div class="mb-3">
                            <label for="new_password" class="form-label">New Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                                <input type="password" class="form-control" id="new_password" name="new_password" required>
                            </div>
                            <small class="form-text text-muted">Password must be at least 6 characters long.</small>
                        </div>
                        
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Confirm New Password <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text"><i class="fas fa-key"></i></span>
                                <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                            </div>
                        </div>
                        
                        <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                            <a href="users.php?action=edit&id=<?php echo $user_data['user_id']; ?>" class="btn btn-outline-secondary me-md-2">
                                <i class="fas fa-times me-2"></i>Cancel
                            </a>
                            <button type="submit" name="reset_password" class="btn btn-warning">
                                <i class="fas fa-key me-2"></i>Reset Password
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
        break;
        
    case 'list':
    default:
        // Get all users
        $users = $user->getAllUsers();
        
        // Display user list
        ?>
        <div class="container py-4">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 data-aos="fade-right">User Management</h1>
                <a href="users.php?action=add" class="btn btn-primary" data-aos="fade-left">
                    <i class="fas fa-user-plus me-2"></i>New User
                </a>
            </div>
            
            <div class="card" data-aos="fade-up">
                <div class="card-body">
                    <?php if (empty($users)): ?>
                        <p class="text-center text-muted">No users found.</p>
                    <?php else: ?>
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Username</th>
                                        <th>Email</th>
                                        <th>Role</th>
                                        <th>Status</th>
                                        <th>Created</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($users as $u): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($u['username']); ?></td>
                                            <td><?php echo htmlspecialchars($u['email']); ?></td>
                                            <td>
                                                <span class="badge bg-<?php 
                                                    echo $u['role_name'] === 'admin' ? 'danger' : 
                                                        ($u['role_name'] === 'manager' ? 'warning' : 'info'); 
                                                ?>">
                                                    <?php echo ucfirst($u['role_name']); ?>
                                                </span>
                                            </td>
                                            <td>
                                                <span class="badge bg-<?php echo $u['is_active'] ? 'success' : 'secondary'; ?>">
                                                    <?php echo $u['is_active'] ? 'Active' : 'Inactive'; ?>
                                                </span>
                                            </td>
                                            <td><?php echo date('M d, Y', strtotime($u['created_at'])); ?></td>
                                            <td>
                                                <div class="btn-group">
                                                    <a href="users.php?action=edit&id=<?php echo $u['user_id']; ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" title="Edit">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="users.php?action=reset_password&id=<?php echo $u['user_id']; ?>" class="btn btn-sm btn-warning" data-bs-toggle="tooltip" title="Reset Password">
                                                        <i class="fas fa-key"></i>
                                                    </a>
                                                    <?php if ($u['user_id'] != $_SESSION['user_id']): ?>
                                                        <form method="POST" action="users.php" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this user? This action cannot be undone.');">
                                                            <input type="hidden" name="user_id" value="<?php echo $u['user_id']; ?>">
                                                            <button type="submit" name="delete_user" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" title="Delete">
                                                                <i class="fas fa-trash-alt"></i>
                                                            </button>
                                                        </form>
                                                    <?php endif; ?>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        break;
}

require_once 'includes/footer.php';
?>
