<?php
/**
 * Home page for Task Management System
 */
require_once 'includes/header.php';
?>

<!-- Add custom CSS for index page buttons -->
<link rel="stylesheet" href="assets/css/index-buttons.css">

<div class="container py-5 my-4">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="text-center mb-5" data-aos="fade-up">
                <h1 class="display-5 fw-bold" style="letter-spacing: -0.5px; text-decoration: none;">Task Management System</h1>
                <p class="lead mb-3" style="color: #8e8e8e !important; font-weight: 400;">Streamlined task management with advanced database features</p>
            </div>
            
            <div class="index-card-container">
                <div class="index-card" data-aos="fade-right" data-aos-delay="100">
                    <div class="card h-100" style="background-color: #101010 !important;">
                        <div class="card-body p-4" style="background-color: #000000 !important;">
                            <h5 class="card-title fw-bold" style="text-decoration: none;"><i class="fas fa-database" style="margin-right: 12px;"></i>Database Features</h5>
                            <ul class="list-group list-group-flush mt-4">
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-code" style="margin-right: 12px;"></i>Stored Procedures for CRUD operations</li>
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-bolt" style="margin-right: 12px;"></i>Triggers for audit logging</li>
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-calendar" style="margin-right: 12px;"></i>Scheduled Events for maintenance</li>
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-users" style="margin-right: 12px;"></i>User Management with roles</li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <div class="index-card" data-aos="fade-left" data-aos-delay="200">
                    <div class="card h-100" style="background-color: #101010 !important;">
                        <div class="card-body p-4" style="background-color: #000000 !important;">
                            <h5 class="card-title fw-bold" style="text-decoration: none;"><i class="fas fa-tasks" style="margin-right: 12px;"></i>System Features</h5>
                            <ul class="list-group list-group-flush mt-4">
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-check-circle" style="margin-right: 12px;"></i>Create, Read, Update and Delete tasks</li>
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-tag" style="margin-right: 12px;"></i>Task categorization</li>
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-flag" style="margin-right: 12px;"></i>Priority management</li>
                                <li class="list-group-item py-3" style="background-color: #101010 !important;"><i class="fas fa-history" style="margin-right: 12px;"></i>Task status tracking</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-5 pt-3" data-aos="fade-up" data-aos-delay="300">
                <?php if (!isLoggedIn()): ?>
                    <p class="mb-4" style="color: #8e8e8e !important; font-size: 1.1rem;">Get started with our task management system today!</p>
                    <div class="buttons-container" style="display: flex; justify-content: center; gap: 10px;">
                        <a href="register.php" class="index-btn index-btn-register" style="margin: 0;"><i class="fas fa-user-plus"></i>Create Account</a>
                        <a href="login.php" class="index-btn index-btn-login" style="margin: 0;"><i class="fas fa-sign-in-alt"></i>Sign In</a>
                    </div>
                <?php else: ?>
                    <p class="mb-4" style="color: #8e8e8e !important; font-size: 1.1rem;">Welcome back, <span style="color: #ffffff !important; font-weight: 600;"><?php echo htmlspecialchars($_SESSION['username']); ?></span>!</p>
                    <a href="dashboard.php" class="index-btn index-btn-register"><i class="fas fa-tachometer-alt"></i>Go to Dashboard</a>
                    <a href="tasks.php" class="index-btn index-btn-login"><i class="fas fa-tasks"></i>View Tasks</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Custom footer for index page only -->
<footer style="background-color: #000000; border-top: 1px solid #333333; padding: 15px 0; text-align: center; position: relative; bottom: 0; width: 100%; margin-top: 50px;">
    <div class="container">
        <p style="color: #ffffff; font-family: 'Poppins', sans-serif; margin: 0; font-size: 14px;">&copy; <?php echo date('Y'); ?> Systematic. All rights reserved.</p>
    </div>
</footer>

<?php require_once 'includes/footer.php'; ?>
