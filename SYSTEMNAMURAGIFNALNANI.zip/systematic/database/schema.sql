-- Database schema for Task Management System

-- Create database
CREATE DATABASE IF NOT EXISTS task_management;
USE task_management;

-- User roles table
CREATE TABLE IF NOT EXISTS roles (
    role_id INT AUTO_INCREMENT PRIMARY KEY,
    role_name VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles
INSERT INTO roles (role_name) VALUES ('admin'), ('manager'), ('user');

-- Users table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role_id INT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(role_id)
);

-- Task categories table
CREATE TABLE IF NOT EXISTS categories (
    category_id INT AUTO_INCREMENT PRIMARY KEY,
    category_name VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default categories
INSERT INTO categories (category_name) VALUES ('Work'), ('Personal'), ('Study'), ('Health'), ('Other');

-- Tasks table
CREATE TABLE IF NOT EXISTS tasks (
    task_id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(100) NOT NULL,
    description TEXT,
    user_id INT NOT NULL,
    category_id INT NOT NULL,
    status ENUM('pending', 'in_progress', 'completed', 'archived') DEFAULT 'pending',
    priority ENUM('low', 'medium', 'high') DEFAULT 'medium',
    due_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (category_id) REFERENCES categories(category_id)
);

-- Audit log table
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    table_name VARCHAR(50) NOT NULL,
    record_id INT NOT NULL,
    action VARCHAR(20) NOT NULL,
    changed_by INT,
    old_values TEXT,
    new_values TEXT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (changed_by) REFERENCES users(user_id)
);

-- Create admin user with stored procedure
DELIMITER //
CREATE PROCEDURE create_admin_user(
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_password VARCHAR(255)
)
BEGIN
    INSERT INTO users (username, email, password, role_id)
    VALUES (p_username, p_email, p_password, 1);
END //
DELIMITER ;

-- Create user stored procedure
DELIMITER //
CREATE PROCEDURE create_user(
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_password VARCHAR(255),
    IN p_role_id INT
)
BEGIN
    INSERT INTO users (username, email, password, role_id)
    VALUES (p_username, p_email, p_password, p_role_id);
    SELECT LAST_INSERT_ID() AS user_id;
END //
DELIMITER ;

-- Update user stored procedure
DELIMITER //
CREATE PROCEDURE update_user(
    IN p_user_id INT,
    IN p_username VARCHAR(50),
    IN p_email VARCHAR(100),
    IN p_role_id INT,
    IN p_is_active BOOLEAN
)
BEGIN
    UPDATE users
    SET username = p_username,
        email = p_email,
        role_id = p_role_id,
        is_active = p_is_active
    WHERE user_id = p_user_id;
END //
DELIMITER ;

-- Get user by credentials stored procedure
DELIMITER //
CREATE PROCEDURE get_user_by_credentials(
    IN p_username VARCHAR(50)
)
BEGIN
    SELECT u.user_id, u.username, u.email, u.password, u.is_active, r.role_name
    FROM users u
    JOIN roles r ON u.role_id = r.role_id
    WHERE u.username = p_username;
END //
DELIMITER ;

-- Create task stored procedure
DELIMITER //
CREATE PROCEDURE create_task(
    IN p_title VARCHAR(100),
    IN p_description TEXT,
    IN p_user_id INT,
    IN p_category_id INT,
    IN p_priority ENUM('low', 'medium', 'high'),
    IN p_due_date DATE
)
BEGIN
    INSERT INTO tasks (title, description, user_id, category_id, priority, due_date)
    VALUES (p_title, p_description, p_user_id, p_category_id, p_priority, p_due_date);
    SELECT LAST_INSERT_ID() AS task_id;
END //
DELIMITER ;

-- Update task stored procedure
DELIMITER //
CREATE PROCEDURE update_task(
    IN p_task_id INT,
    IN p_title VARCHAR(100),
    IN p_description TEXT,
    IN p_category_id INT,
    IN p_status ENUM('pending', 'in_progress', 'completed', 'archived'),
    IN p_priority ENUM('low', 'medium', 'high'),
    IN p_due_date DATE
)
BEGIN
    UPDATE tasks
    SET title = p_title,
        description = p_description,
        category_id = p_category_id,
        status = p_status,
        priority = p_priority,
        due_date = p_due_date
    WHERE task_id = p_task_id;
END //
DELIMITER ;

-- Get tasks by user stored procedure
DELIMITER //
CREATE PROCEDURE get_tasks_by_user(
    IN p_user_id INT
)
BEGIN
    SELECT t.*, c.category_name
    FROM tasks t
    JOIN categories c ON t.category_id = c.category_id
    WHERE t.user_id = p_user_id AND t.status != 'archived'
    ORDER BY t.due_date ASC, t.priority DESC;
END //
DELIMITER ;

-- Delete task stored procedure
DELIMITER //
CREATE PROCEDURE delete_task(
    IN p_task_id INT
)
BEGIN
    DELETE FROM tasks WHERE task_id = p_task_id;
END //
DELIMITER ;

-- Trigger for task audit logging
DELIMITER //
CREATE TRIGGER after_task_insert
AFTER INSERT ON tasks
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, new_values)
    VALUES ('tasks', NEW.task_id, 'INSERT', NEW.user_id, 
            CONCAT('{"title":"', NEW.title, 
                  '","description":"', COALESCE(NEW.description, ''), 
                  '","category_id":', NEW.category_id, 
                  ',"status":"', NEW.status, 
                  '","priority":"', NEW.priority, 
                  '","due_date":"', COALESCE(NEW.due_date, ''), '"}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_task_update
AFTER UPDATE ON tasks
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, old_values, new_values)
    VALUES ('tasks', NEW.task_id, 'UPDATE', NEW.user_id,
            CONCAT('{"title":"', OLD.title, 
                  '","description":"', COALESCE(OLD.description, ''), 
                  '","category_id":', OLD.category_id, 
                  ',"status":"', OLD.status, 
                  '","priority":"', OLD.priority, 
                  '","due_date":"', COALESCE(OLD.due_date, ''), '"}'),
            CONCAT('{"title":"', NEW.title, 
                  '","description":"', COALESCE(NEW.description, ''), 
                  '","category_id":', NEW.category_id, 
                  ',"status":"', NEW.status, 
                  '","priority":"', NEW.priority, 
                  '","due_date":"', COALESCE(NEW.due_date, ''), '"}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_task_delete
AFTER DELETE ON tasks
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, old_values)
    VALUES ('tasks', OLD.task_id, 'DELETE',
            CONCAT('{"title":"', OLD.title, 
                  '","description":"', COALESCE(OLD.description, ''), 
                  '","category_id":', OLD.category_id, 
                  ',"status":"', OLD.status, 
                  '","priority":"', OLD.priority, 
                  '","due_date":"', COALESCE(OLD.due_date, ''), '"}'));
END //
DELIMITER ;

-- Trigger for user audit logging
DELIMITER //
CREATE TRIGGER after_user_insert
AFTER INSERT ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, new_values)
    VALUES ('users', NEW.user_id, 'INSERT', NEW.user_id, 
            CONCAT('{"username":"', NEW.username, 
                  '","email":"', NEW.email, 
                  '","role_id":', NEW.role_id, 
                  ',"is_active":', NEW.is_active, '}'));
END //
DELIMITER ;

DELIMITER //
CREATE TRIGGER after_user_update
AFTER UPDATE ON users
FOR EACH ROW
BEGIN
    INSERT INTO audit_logs (table_name, record_id, action, changed_by, old_values, new_values)
    VALUES ('users', NEW.user_id, 'UPDATE', NEW.user_id,
            CONCAT('{"username":"', OLD.username, 
                  '","email":"', OLD.email, 
                  '","role_id":', OLD.role_id, 
                  ',"is_active":', OLD.is_active, '}'),
            CONCAT('{"username":"', NEW.username, 
                  '","email":"', NEW.email, 
                  '","role_id":', NEW.role_id, 
                  ',"is_active":', NEW.is_active, '}'));
END //
DELIMITER ;

-- Scheduled event to archive completed tasks older than 30 days
DELIMITER //
CREATE EVENT archive_completed_tasks
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    UPDATE tasks
    SET status = 'archived'
    WHERE status = 'completed'
    AND updated_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
END //
DELIMITER ;

-- Scheduled event to clean up audit logs older than 90 days
DELIMITER //
CREATE EVENT cleanup_old_audit_logs
ON SCHEDULE EVERY 7 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    DELETE FROM audit_logs
    WHERE timestamp < DATE_SUB(NOW(), INTERVAL 90 DAY);
END //
DELIMITER ;

-- Make sure event scheduler is turned on
SET GLOBAL event_scheduler = ON;

-- Create a default admin user (password: admin123)
CALL create_admin_user('admin', 'admin@example.com', '$2y$10$8tG5bxNTmNyFv.szTzWYZ.XG1hSLYt/8JF7lYRXdJfzOKVPnP9.5m');
