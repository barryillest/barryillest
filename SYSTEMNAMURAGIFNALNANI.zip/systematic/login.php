<?php
/**
 * Login page for Task Management System
 */
// Start session and include necessary files for authentication
require_once 'includes/session.php';
require_once 'config/database.php';
require_once 'includes/user.php';

// Initialize database connection and user object
$database = new Database();
$db = $database->getConnection();
$user = new User($db);

// Check if user is already logged in
if (isLoggedIn()) {
    header("Location: dashboard.php");
    exit();
}

// Get flash message if any
$flash = getFlashMessage();

// Process login form
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    $remember = isset($_POST['remember']);
    
    // Validate input
    if (empty($username) || empty($password)) {
        setFlashMessage('danger', 'Please enter both username and password.');
    } else {
        // Attempt to login
        if ($user->login($username, $password)) {
            // Set remember me cookie if requested
            if ($remember) {
                setcookie('remember_user', $_SESSION['user_id'], time() + (86400 * 30), '/'); // 30 days
            }
            
            setFlashMessage('success', 'Welcome back, ' . $_SESSION['username'] . '!');
            header("Location: dashboard.php");
            exit();
        } else {
            setFlashMessage('danger', 'Invalid username or password.');
        }
    }
    
    // Redirect to refresh the page and show flash message
    header("Location: login.php");
    exit();
}

// Include the header after all potential redirects
require_once 'includes/header.php';
?>

<!-- Add auth.css for login/register styling -->
<link rel="stylesheet" href="assets/css/auth.css">

<div class="auth-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="auth-form">
                    <div class="card">
                        <div class="card-body">
                            <h2 class="card-title">Login</h2>
                        
                        <form method="POST" action="login.php">
                            <div class="mb-3">
                                <label for="username" class="form-label">Username</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-user"></i></span>
                                    <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username" required autofocus>
                                </div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="password" class="form-label">Password</label>
                                <div class="input-group">
                                    <span class="input-group-text"><i class="fas fa-lock"></i></span>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Enter your password" required>
                                </div>
                            </div>
                            
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="remember" name="remember">
                                <label class="form-check-label" for="remember">Remember me</label>
                            </div>
                            
                            <div class="text-center">
                                <button type="submit" class="btn btn-outline-secondary" style="background-color: #000000; min-width: 220px;">
                                    <i class="fas fa-sign-in-alt" style="margin-right: 12px;"></i>Login to your account
                                </button>
                            </div>
                        </form>
                        
                        <div class="mt-4 text-center">
                            <p>Don't have an account? <a href="register.php">Create an account</a></p>
                            <p class="mt-3"><a href="index.php" class="btn btn-outline-secondary"><i class="fas fa-home" style="margin-right: 12px;"></i>Back to Home</a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once 'includes/footer.php'; ?>
